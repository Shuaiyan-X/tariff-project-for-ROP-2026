import mesa
import numpy as np
import pandas as pd
from agents_v0_0 import Consumer, Firm
from mesa.datacollection import DataCollector

class Model(mesa.Model):
    def __init__(self, consumer_num = 100, firm_num = 1, seed=None):
        super().__init__(seed=seed)
        # create firm_num firm agents and consumer_num consumer agents
        Firm.create_agents(model=self, n=firm_num)
        Consumer.create_agents(model=self, n=consumer_num)
        ## global economic data structures (dynamic)
        self.prices = {}
        self.demand = {}
        self.supply = {}
        ## economic aggregate variables
        self.num_consumers = consumer_num
        self.num_firms = firm_num
        self.total_production = 0
        self.avg_price = 0
        self.avg_utility = 0
        # DataCollector for this model
        self.datacollector = DataCollector(
            model_reporters={
                "avg_price": lambda m: m.avg_price,
                "total_production": lambda m: m.total_production,
                "avg_utility": lambda m: m.avg_utility,
                "num_consumers": lambda m: m.num_consumers,
                "num_firms": lambda m: m.num_firms,
            },
            agent_reporters={
                "type": lambda a: type(a).__name__,
                # firm fields
                "firm_price": lambda a: a.price if isinstance(a, Firm) else np.nan,
                "firm_profit": lambda a: a.profit[0] if isinstance(a, Firm) else np.nan,
                # consumer fields
                "cons_utility": lambda a: a.utility if isinstance(a, Consumer) else np.nan,
                # shared-ish field (both have money in your code)
                "money": lambda a: getattr(a, "money", np.nan),
            },
        )
        print("(DEBUG) Model Initialized")
        print("(DEBUG) DataCollector Initialized?", hasattr(self, "datacollector"))

    def step(self):
        """
        One full period of the economy:
        - Consumers work()
        - Firms set prices → model collects prices
        - Consumers choose_consumption()
        - Model aggregates demand
        - Firms produce()
        - Consumers consume()
        - Compute and record aggregate statistics
        - Reset for the next period
        """
        # stage 1: consumers work
        for agent in self.agents:
            if isinstance(agent, Consumer):
                agent.work()
        # collect prices from firms
        self.prices = {
            agent.unique_id: agent.price
            for agent in self.agents
            if isinstance(agent, Firm)
        }
        # stage 2: consumers choose consumption
        for agent in self.agents:
            if isinstance(agent, Consumer):
                agent.choose_consumption()
        # get aggregate demand
        self.demand = {firm_id: 0 for firm_id in self.prices}
        for agent in self.agents:
            if isinstance(agent, Consumer):
                indiv = agent.consume_queue[0]
                for firm_id in indiv.keys():
                    self.demand[firm_id] += indiv[firm_id]
        # stage 3: firms produce
        self.supply = {}
        for agent in self.agents:
            if isinstance(agent, Firm):
                produced = agent.produce(self.demand)
                # can use (dict).get(key, val if key DNE)
                self.supply[agent.unique_id] = produced
        self.total_production = sum(self.supply.values())
            # need to record before consumers consume it all
        # stage 4: consumers consume
        for agent in self.agents:
            if isinstance(agent, Consumer):
                agent.consume()
        # stage 5: record other aggregates
        self.avg_price = sum(self.prices.values()) / len(self.prices)
        self.avg_utility = (
            sum(agent.utility for agent in self.agents if isinstance(agent, Consumer))
            / self.num_consumers
        )
        # collect here (must be BEFORE you reset to 0)
        self.datacollector.collect(self)
        # stage 6: firms update their prices
        for agent in self.agents:
            if isinstance(agent, Firm):
                agent.update_prices()
        # stage 7: reset everything
        self.prices = {}
        self.demand = {}
        self.supply = {}
        self.total_production = 0
        self.avg_price = 0
        self.avg_utility = 0
        for agent in self.agents:
            agent.reset()