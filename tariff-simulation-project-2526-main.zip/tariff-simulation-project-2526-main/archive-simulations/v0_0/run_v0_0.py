import mesa
import numpy as np
import pandas as pd
import seaborn as sns
import random
from model_v0_0 import Model
from agents_v0_0 import Consumer, Firm

random.seed(67)

# consumer income: max(random.gauss(mu=100.0, sigma=10.0), 1)
# consumer alpha: random.uniform(0, 1)
# firm capital: max(random.gauss(mu=10.0, sigma=1.0), 1)
# firm labor: max(random.gauss(mu=10.0, sigma=1.0), 1)
# firm fixed cost: max(random.gauss(mu=fixed_cost_mean, sigma=fixed_cost_std), 1)
# firm price: max(random.gauss(mu=init_price_mean, sigma=init_price_std), 0.01) 

sample_model = Model(consumer_num=1)
print(dir(sample_model))