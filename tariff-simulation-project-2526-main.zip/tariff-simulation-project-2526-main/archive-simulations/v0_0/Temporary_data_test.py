# ============================================================
# This script:
# 1) Confirms the import path
# 2) Initializes the model
# 3) Runs the simulation for T periods
# 4) Extracts model-level time series and agent-level panel data
# 5) Splits agents into Firm vs Consumer tables
# 6) Saves CSV outputs and prints quick previews
# ============================================================

import model_v0_0
print("IMPORTING FROM:", model_v0_0.__file__)

from model_v0_0 import Model

# ------------------------------------------------------------
# 1) Initialize the model (set sizes + seed for reproducibility)
# ------------------------------------------------------------
m = Model(consumer_num=100, firm_num=3, seed=1)

# ------------------------------------------------------------
# 2) Run the simulation for T time steps (periods)
# ------------------------------------------------------------
T = 50
for t in range(T):
    m.step()

print("Simulation finished.")

# ------------------------------------------------------------
# 3) Get model-level data (one row per time step)
# ------------------------------------------------------------
df_model = m.datacollector.get_model_vars_dataframe()

print("\nModel-level data preview:")
print(df_model.head())

# ------------------------------------------------------------
# 4) Get agent-level data (panel: one row per agent per time step)
# reset_index() converts Step and AgentID from index into columns
# ------------------------------------------------------------
df_agent = m.datacollector.get_agent_vars_dataframe().reset_index()

print("\nAgent columns:")
print(df_agent.columns.tolist())

# ------------------------------------------------------------
# 5) Split the agent panel by agent type
# Firms and Consumers are stored together, so we filter by 'type'
# ------------------------------------------------------------
df_firm = df_agent[df_agent["type"] == "Firm"].copy()
df_cons = df_agent[df_agent["type"] == "Consumer"].copy()

# (Optional) Keep only the most relevant columns for each type
firm_cols = ["Step", "AgentID", "firm_price", "firm_profit", "money"]
cons_cols = ["Step", "AgentID", "cons_utility", "money"]

# If some columns are missing due to your reporter names, comment
# these two lines out and just save df_firm/df_cons directly.
df_firm = df_firm[firm_cols]
df_cons = df_cons[cons_cols]

# ------------------------------------------------------------
# 6) Save outputs to CSV files
# - model_data.csv: time series
# - firm_data.csv : firm panel
# - consumer_data.csv : consumer panel
# ------------------------------------------------------------
df_model.to_csv("model_data_0_0.csv", index=False)
df_firm.to_csv("firm_data_0_0.csv", index=False)
df_cons.to_csv("consumer_data_0_0.csv", index=False)

print("\nSaved model_data_0_0.csv, firm_data_0_0.csv"
" and consumer_data_0_0.csv")

# ------------------------------------------------------------
# 7) Quick sanity checks (print previews)
# head(): early periods; tail(): latest periods
# ------------------------------------------------------------
print("\nFirm preview (first 5 rows):")
print(df_firm.head())

print("\nFirm preview (last 5 rows):")
print(df_firm.tail())

print("\nConsumer preview (first 5 rows):")
print(df_cons.head())

print("\nConsumer preview (last 5 rows):")
print(df_cons.tail())

# ------------------------------------------------------------
# 8) Extra checks (optional): verify sizes
# Expected:
# - firm rows ~ T * firm_num
# - consumer rows ~ T * consumer_num
# ------------------------------------------------------------
print("\nRow counts:")
print("Firm rows:", len(df_firm))
print("Consumer rows:", len(df_cons))