import mesa
# mariamthedev was here
import numpy as np
import random
from scipy.optimize import minimize
# import pandas as pd
# NOTE: check out optimization libraries PuLP, Pyomo, cvxpy

## some general functions that are useful for the agents
def neg_utility(c, alpha):
    """A helper function for calculating a standard convex increasing
    utility for a given level of consumption c, but negative."""
    c = c[0] # c an array by default, convert to scalar
    if c < 0:
        return -np.inf
    return -(c**alpha)

def optimize_consumption(price, income, alpha):
    """The consumer maximizes u(c)=c^alpha subject to pc = I."""
    # Upper bound: full budget spent
    c_max = income / price
    res = minimize(
        neg_utility,
        x0=np.array([c_max * 0.5]),  # initial guess
        args=(alpha,),
        bounds=[(0, c_max)]
    )
    if not res.success:
        # fallback: consume full budget
        return c_max, neg_utility([c_max], alpha)
    c_opt = res.x[0]
    u_opt = -res.fun  # convert back to positive utility
    return c_opt, u_opt


class Consumer(mesa.Agent):
    """
    The most basic consumer agent we make for this project. Consumers
    earn exogenous income and then make a consumption choice each period
    given the firms' posted prices, earning utility.
    """
    def __init__(self, model:mesa.Model, income=100.0, alpha=0.67):
        super().__init__(model)
        ## static parameters
        self.income = income
        self.alpha = alpha # Cobb-Douglas preference structure
        ## dynamic parameters
        self.utility = 0
        self.consume_queue = [] # queue for indiv demand for each firm
        self.money = 0
    
    def work(self):
        """Earn exogenous income. (For more advanced agents later, this
        will be something more sophisticated.)"""
        self.money += self.income
    
    def choose_consumption(self):
        """The consumer maximizes the utiility function u(c)=c^ALPHA subject
        to a standard budget constraint."""
        opt_choice = {"firms": "", "consumption": 0, "utility": -np.inf}
        for firm in self.model.prices:
            this_choice = optimize_consumption(self.model.prices[firm],
                                                self.money, self.alpha)
            if this_choice[1] >= opt_choice["utility"]:
                opt_choice["firms"] = firm
                opt_choice["consumption"] = this_choice[0]
                opt_choice["utility"] = this_choice[1]
        own_demand = {firm: 0 for firm in self.model.prices}
        own_demand[opt_choice["firms"]] += opt_choice["consumption"]
        self.consume_queue.append(own_demand)
    
    def consume(self):
        """Buy chosen amounts of consumption goods, gaining utility."""
        own_demand = self.consume_queue.pop(0)
        consumption = 0
        for firm in own_demand:
            # either got everything desired or was limited by firm supply
            bought = min(own_demand[firm], self.model.supply[firm])
            self.money -= bought * self.model.prices[firm]
            self.model.supply[firm] -= bought
            consumption += bought
        util_gain = consumption ** self.alpha
        self.utility += util_gain
        return consumption, util_gain
    
    def reset(self):
        """Resets the agent for the next time step."""    
        self.utility = 0
        self.money = 0


class Firm(mesa.Agent):
    """
    The most basic firm agent we make for this project. Firms post prices,
    then produce as much as needed to match consumer demand. After this,
    firms update their prices for the next period.
    """
    def __init__(self, model:mesa.Model, 
                 capital=5.0, labor=10.0, price=2.0, fixed_cost=3.0,
                 adjust_rate=0.05, cost_params=(1, 2)):
        super().__init__(model)
        ## static parameters
        self.cost_params = cost_params # MC = 1/2 cost(0) q^2 + cost(1) q
        # K, L don't matter for now since production always clears demand
        self.adjust_rate = adjust_rate
            # K, L will be more dynamic in future model iterations
        self.fixed_cost = fixed_cost
        ## dynamic parameters
        self.money = 0
        self.price = price
        self.profit = [0, 0] # [this period's profit, last period's profit]
            # this structure makes profit[x] be a lookback x periods ago

    def produce(self, demand):
        """The firm observes global market demand and produces to match it,
        incurring costs and making revenue. Total production is returned."""
        firm_demand = self.model.demand[self.unique_id]
        firm_supply = firm_demand # will be more dynamic in later models
        revenue = self.price * firm_supply
        cost = 0.5 * self.cost_params[0] * firm_supply ** 2 \
                + self.cost_params[1] * firm_supply
        if firm_supply != 0:
            cost += self.fixed_cost
        profit = revenue - cost
        self.money += profit
        self.profit[0] = profit
        return firm_supply
    
    def update_prices(self):
        """Check present profits against past profits. If the firm makes more
        money in the present period, increase prices. Otherwise, lower it."""
        if self.profit[0] > self.profit[1]:
            self.price *= (1 + self.adjust_rate)
        else:
            self.price *= (1 - self.adjust_rate)
        self.profit[1] = self.profit[0]
    
    def reset(self):
        """Resets the agent for the next time step."""    
        self.money = 0