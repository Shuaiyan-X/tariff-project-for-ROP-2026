"""
Compare pre-mod and post-mod sweep results for heterogeneous scenario.
Produces scatter plots and prints simple summary statistics.
"""
from pathlib import Path
import pandas as pd
import matplotlib.pyplot as plt
import json

ROOT = Path(__file__).resolve().parent
OUT = ROOT / 'results' / 'analysis_post_mod'
OUT.mkdir(parents=True, exist_ok=True)

pre = ROOT / 'results' / 'sweep_heterogeneous' / 'sweep_results.csv'
post = ROOT / 'results' / 'sweep_modified_hetero_small' / 'sweep_results.csv'

if not pre.exists() or not post.exists():
    print('Required files missing:', pre, post)
    raise SystemExit(1)

df_pre = pd.read_csv(pre)
df_post = pd.read_csv(post)

# compute simple summaries
summary = {
    'pre': {
        'n': int(len(df_pre)),
        'stable_count': int(df_pre['stable_all'].sum()) if 'stable_all' in df_pre else 0,
        'mean_inv_slope': float(df_pre['inv_slope'].mean()),
        'mean_profit_slope': float(df_pre['profit_slope'].mean()),
    },
    'post': {
        'n': int(len(df_post)),
        'stable_count': int(df_post['stable_all'].sum()) if 'stable_all' in df_post else 0,
        'mean_inv_slope': float(df_post['inv_slope'].mean()),
        'mean_profit_slope': float(df_post['profit_slope'].mean()),
    }
}

with open(OUT / 'summary.json', 'w') as f:
    json.dump(summary, f, indent=2)

print('Summary written to', OUT / 'summary.json')
print(summary)

pairs = [
    ('inv_slope', 'inv_mean', 'Inventory slope vs mean'),
    ('profit_slope', 'profit_mean', 'Profit slope vs mean'),
    ('initial_avg_income', 'final_avg_income', 'Final vs Initial Average Income'),
]

for xcol, ycol, title in pairs:
    plt.figure(figsize=(6, 4))
    if xcol in df_pre and ycol in df_pre:
        plt.scatter(df_pre[xcol], df_pre[ycol], label='pre-mod', alpha=0.6)
    if xcol in df_post and ycol in df_post:
        plt.scatter(df_post[xcol], df_post[ycol], label='post-mod', alpha=0.8)
    plt.axhline(0, color='k', lw=0.5)
    plt.axvline(0, color='k', lw=0.5)
    plt.xlabel(xcol)
    plt.ylabel(ycol)
    plt.title(title)
    plt.legend()
    plt.tight_layout()
    plt.savefig(OUT / f'compare_{xcol}_vs_{ycol}.png')
    plt.close()
    print('Saved', OUT / f'compare_{xcol}_vs_{ycol}.png')
