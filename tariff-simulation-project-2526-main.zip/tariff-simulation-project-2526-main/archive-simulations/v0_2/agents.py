from mesa import Agent
import numpy as np

# Numerical safeguards
P_MIN = 1e-8
Q_MIN = 1e-12
S_MIN = 1e-12


class Household(Agent):
    def __init__(self, model,
                 L0, K0, n, s,
                 theta, alpha, N,
                 lambda_p, lambda_w, lambda_r,
                 dx, dy, sigma_x, sigma_y):
        super().__init__(model)

        # Endowments and growth
        self.L = L0
        self.K = K0
        self.n = n
        self.s = s

        # Preferences
        self.theta = theta      # Cobb-Douglas share on x
        self.alpha = alpha      # discount factor
        self.N = int(N)         # lookahead horizon
        self.dx = dx            # home bias for x
        self.dy = dy            # home bias for y
        self.sigma_x = sigma_x  # CES elasticity for x
        self.sigma_y = sigma_y  # CES elasticity for y

        # Sticky expectations
        self.lambda_p = lambda_p
        self.lambda_w = lambda_w
        self.lambda_r = lambda_r

        # Expected aggregates
        self.p_hat = None
        self.w_hat = None
        self.r_hat = None

        # Money / assets
        self.money = 0.0

        # Last-period choices
        self.xd = self.xm = 0.0
        self.yd = self.ym = 0.0

    # ------------------------------------------------------------------
    # Endowment updates
    # ------------------------------------------------------------------
    def update_endowments(self):
        self.L *= (1 + self.n)
        self.K *= (1 + self.s)

    # ------------------------------------------------------------------
    # Sticky expectations
    # ------------------------------------------------------------------
    def update_expectations(self):
        firm = self.model.firm
        Px_current, Py_current = firm.get_aggregate_gross_prices()

        # Expected aggregate price level (single p_hat)
        if self.p_hat is None:
            self.p_hat = 0.5 * (Px_current + Py_current)
        else:
            self.p_hat = (
                self.lambda_p * 0.5 * (Px_current + Py_current)
                + (1 - self.lambda_p) * self.p_hat
            )

        # Expected wage
        if self.w_hat is None:
            self.w_hat = firm.w
        else:
            self.w_hat = (
                self.lambda_w * firm.w +
                (1 - self.lambda_w) * self.w_hat
            )

        # Expected rental rate
        if self.r_hat is None:
            self.r_hat = firm.r
        else:
            self.r_hat = (
                self.lambda_r * firm.r +
                (1 - self.lambda_r) * self.r_hat
            )

    # ------------------------------------------------------------------
    # Income
    # ------------------------------------------------------------------
    def compute_income(self):
        firm = self.model.firm
        return firm.w * self.L + firm.r * self.K

    # ------------------------------------------------------------------
    # CES aggregation helpers
    # ------------------------------------------------------------------
    def inst_utility(self, xd, xm, yd, ym):
        x = aggregate_q(self.dx, xd, xm, self.sigma_x)
        y = aggregate_q(self.dy, yd, ym, self.sigma_y)
        return (x ** self.theta) * (y ** (1 - self.theta))

    # ------------------------------------------------------------------
    # N-period optimization (tariff-correct)
    # ------------------------------------------------------------------
    def optimize_consumption_path(self, income_t):
        firm = self.model.firm

        # Households face GROSS prices
        # copy and clamp gross prices to avoid zero-division
        p_raw = firm.p_gross
        p = {k: max(float(p_raw.get(k, 0.0)), P_MIN) for k in p_raw}

        # Current resources
        transfer_t = self.model.gov.transfer_for(self)
        current_resources = float(self.money + income_t + transfer_t)

        # Expected incomes for future periods
        incomes = np.zeros(self.N)
        incomes[0] = income_t

        L0 = float(self.L)
        K0 = float(self.K)

        for t in range(1, self.N):
            L_future = L0 * ((1 + self.n) ** t)
            K_future = K0 * ((1 + self.s) ** t)
            incomes[t] = float(self.w_hat * L_future + self.r_hat * K_future)

        # Spending bounds
        ub = np.zeros(self.N)
        ub[0] = max(0.0, current_resources)
        if self.N > 1:
            ub[1:] = np.maximum(0.0, incomes[1:])

        # CES aggregate prices (gross)
        P_x = aggregate_p(p["xd"], p["xm"], self.dx, self.sigma_x)
        P_y = aggregate_p(p["yd"], p["ym"], self.dy, self.sigma_y)

        # CES shares
        def ces_shares(p_d, p_m, delta, sigma):
            # clamp prices
            p_d = max(float(p_d), P_MIN)
            p_m = max(float(p_m), P_MIN)
            if sigma == 1:
                return float(delta), float(1 - delta)
            den = delta * p_d**(1 - sigma) + (1 - delta) * p_m**(1 - sigma)
            if den == 0 or not np.isfinite(den):
                return float(delta), float(1 - delta)
            s_d = delta * p_d**(1 - sigma) / den
            s_m = (1 - delta) * p_m**(1 - sigma) / den
            return float(s_d), float(s_m)

        s_xd, s_xm = ces_shares(p["xd"], p["xm"], self.dx, self.sigma_x)
        s_yd, s_ym = ces_shares(p["yd"], p["ym"], self.dy, self.sigma_y)

        # Utility from expenditure
        def util_from_E(E):
            E_x = self.theta * E
            E_y = (1 - self.theta) * E

            # avoid division by (near) zero prices
            xd = (s_xd * E_x) / max(p.get("xd", P_MIN), P_MIN)
            xm = (s_xm * E_x) / max(p.get("xm", P_MIN), P_MIN)
            yd = (s_yd * E_y) / max(p.get("yd", P_MIN), P_MIN)
            ym = (s_ym * E_y) / max(p.get("ym", P_MIN), P_MIN)

            return self.inst_utility(xd, xm, yd, ym)

        # Objective for optimizer
        def objective(M_vec):
            total = 0.0
            for t in range(self.N):
                Et = max(0.0, float(M_vec[t]))
                total += (self.alpha ** t) * util_from_E(Et)
            return -total

        # Bounds
        bounds = [(0.0, float(ub_t)) for ub_t in ub]

        # Initial guess
        x0 = np.minimum(ub, np.maximum(0.0, incomes))

        # Try scipy.optimize
        try:
            from scipy.optimize import minimize
            res = minimize(objective, x0, bounds=bounds, method="SLSQP")
            if res.success:
                M_opt = np.maximum(0.0, np.minimum(ub, res.x))
            else:
                M_opt = x0.copy()
        except Exception:
            M_opt = x0.copy()

        # First-period consumption
        E0 = float(M_opt[0])
        E0_x = self.theta * E0
        E0_y = (1 - self.theta) * E0

        # clamp denominators to avoid division by zero
        xd = (s_xd * E0_x) / max(p.get("xd", P_MIN), P_MIN)
        xm = (s_xm * E0_x) / max(p.get("xm", P_MIN), P_MIN)
        yd = (s_yd * E0_y) / max(p.get("yd", P_MIN), P_MIN)
        ym = (s_ym * E0_y) / max(p.get("ym", P_MIN), P_MIN)

        # Spending at gross prices
        spending_now = (
            xd * p["xd"] +
            xm * p["xm"] +
            yd * p["yd"] +
            ym * p["ym"]
        )

        saving_now = max(0.0, current_resources - spending_now)

        return float(xd), float(xm), float(yd), float(ym), float(saving_now)

    # ------------------------------------------------------------------
    # Mesa step
    # ------------------------------------------------------------------
    def step(self):
        self.update_endowments()
        self.update_expectations()

        income_t = self.compute_income()

        xd, xm, yd, ym, saving = self.optimize_consumption_path(income_t)

        # Register demand
        self.model.firm.register_demand(self, xd, xm, yd, ym)

        # Spending at gross prices
        spending = self.model.firm.compute_gross_spending(xd, xm, yd, ym)

        # Update money
        self.money += income_t + self.model.gov.transfer_for(self) - spending - saving

        # Store choices
        self.xd, self.xm, self.yd, self.ym = xd, xm, yd, ym


# ----------------------------------------------------------------------
# CES helper functions
# ----------------------------------------------------------------------

def aggregate_q(delta, qd, qm, sigma):
    # clamp quantities to avoid log(0) or zero**power issues
    qd = max(float(qd), Q_MIN)
    qm = max(float(qm), Q_MIN)
    if sigma == 1:
        return float(np.exp(delta * np.log(qd) + (1 - delta) * np.log(qm)))
    # guard against sigma == 0
    if sigma == 0:
        return float(delta * qd + (1 - delta) * qm)
    weight = (sigma - 1) / sigma
    val = (delta * qd**weight + (1 - delta) * qm**weight) ** (1 / weight)
    return float(val)


def aggregate_p(p_d, p_m, delta, sigma):
    # clamp prices to avoid zero/negative values
    p_d = max(float(p_d), P_MIN)
    p_m = max(float(p_m), P_MIN)
    if sigma == 1:
        return float(np.exp(delta * np.log(p_d) + (1 - delta) * np.log(p_m)))
    # guard against 1 - sigma == 0 handled above
    val = (delta * p_d**(1 - sigma) + (1 - delta) * p_m**(1 - sigma)) ** (1 / (1 - sigma))
    return float(val)

class Firm(Agent):
    GOODS = ["xd", "xm", "yd", "ym"]

    def __init__(self, model,
                 z, beta_L, beta_K,
                 np_price,
                 alpha_m, alpha_I, eta_s,
                 eta_w, eta_r,
                 c_d, c_m,
                 eta_d=0.0):
        super().__init__(model)

        # Production function parameters
        self.z = z
        self.beta_L = beta_L
        self.beta_K = beta_K

        # Factor prices
        self.w = 1.0
        self.r = 1.0

        # Net prices (what firm receives)
        self.p = {g: 1.0 for g in self.GOODS}

        # Gross prices (what households pay, includes tariffs)
        self.p_gross = {g: 1.0 for g in self.GOODS}

        # Unit costs
        self.c = {
            "xd": c_d,
            "xm": c_m,
            "yd": 1.0,
            "ym": 1.0,
        }

        # Production shares (sum to 1)
        self.s = {g: 1.0 / len(self.GOODS) for g in self.GOODS}

        # Actual production, demand, inventory
        self.y = {g: 0.0 for g in self.GOODS}
        self.q = {g: 0.0 for g in self.GOODS}
        self.I = {g: 0.0 for g in self.GOODS}
        # Actual sales (fulfilled demand) in the current period
        self.sales = {g: 0.0 for g in self.GOODS}

        # Demand buffer
        self._demand_buffer = []

        # Parameters
        self.np_price = np_price      # price adjustment speed
        self.alpha_m = alpha_m        # weight on margin in share update
        self.alpha_I = alpha_I        # weight on inventory drift
        self.eta_s = eta_s            # share adjustment speed
        self.eta_w = eta_w            # wage update speed
        self.eta_r = eta_r            # rental rate update speed
        self.eta_d = eta_d            # demand-supply price response

    # --- production capacity ---

    def production_capacity(self, L, K):
        return self.z * (L ** self.beta_L) * (K ** self.beta_K)

    # --- price level for expectations ---

    def get_price_level(self):
        # Simple average of gross prices as a "price level"
        return np.mean(list(self.p_gross.values()))

    # --- Armington aggregate prices (gross, for households) ---

    def get_aggregate_gross_prices(self):
        # Simple average; you can plug in CES if you like
        Px = 0.5 * (self.p_gross["xd"] + self.p_gross["xm"])
        Py = 0.5 * (self.p_gross["yd"] + self.p_gross["ym"])
        return Px, Py

    # --- demand registration ---

    def register_demand(self, household, xd, xm, yd, ym):
        self._demand_buffer.append({
            "xd": xd, "xm": xm, "yd": yd, "ym": ym
        })

    def clear_demand(self):
        self.q = {g: 0.0 for g in self.GOODS}
        for bundle in self._demand_buffer:
            for g in self.GOODS:
                self.q[g] += bundle[g]
        self._demand_buffer = []

    # --- compute sales and update inventories based on available supply ---
    def settle_sales_and_update_inventories(self):
        # Keep a copy of previous inventory
        I_prev = {g: float(self.I.get(g, 0.0)) for g in self.GOODS}
        sold = {}
        for g in self.GOODS:
            available = float(self.y.get(g, 0.0)) + max(0.0, I_prev.get(g, 0.0))
            demand = float(self.q.get(g, 0.0))
            sold_g = min(demand, available)
            sold[g] = sold_g

        # update sales record
        self.sales = {g: float(sold[g]) for g in self.GOODS}

        # update inventories (never go below zero)
        for g in self.GOODS:
            self.I[g] = I_prev.get(g, 0.0) + float(self.y.get(g, 0.0)) - float(self.sales.get(g, 0.0))

    # --- spending at gross prices ---

    def compute_gross_spending(self, xd, xm, yd, ym):
        return (xd * self.p_gross["xd"] +
                xm * self.p_gross["xm"] +
                yd * self.p_gross["yd"] +
                ym * self.p_gross["ym"])

    # --- inventory update ---

    def update_inventories(self):
        for g in self.GOODS:
            self.I[g] += self.y[g] - self.q[g]

    # --- update gross prices from net prices and tariff ---

    def update_gross_prices_from_tariff(self):
        tau = self.model.gov.tau if self.model.gov is not None else 0.0
        # Domestic goods: no tariff
        self.p_gross["xd"] = self.p["xd"]
        self.p_gross["yd"] = self.p["yd"]
        # Imported goods: ad valorem tariff
        self.p_gross["xm"] = (1 + tau) * self.p["xm"]
        self.p_gross["ym"] = (1 + tau) * self.p["ym"]

    # --- price update (zero-profit target, net prices) ---

    def update_goods_prices(self):
        for g in self.GOODS:
            margin = self.p[g] - self.c[g]
            # move net prices partly toward zero profit margins
            self.p[g] -= self.np_price * margin

            # adjust prices in response to unmet demand: if demand > sales,
            # raise price slightly; if sales > demand, lower price slightly.
            qg = float(self.q.get(g, 0.0))
            sold = float(self.sales.get(g, 0.0))
            denom = (qg + sold) + P_MIN
            diff_norm = (qg - sold) / denom
            # multiplicative adjustment, but cap changes per step to avoid large swings
            factor = 1.0 + float(self.eta_d) * diff_norm
            factor = np.clip(factor, 1.0 - 0.1, 1.0 + 0.1)
            self.p[g] *= float(factor)

            # clamp
            self.p[g] = max(P_MIN, float(self.p[g]))

    # --- production share update (replicator dynamics) ---

    def update_production_shares(self):
        z = {}
        for g in self.GOODS:
            margin = self.p[g] - self.c[g]
            delta_I = self.y[g] - self.q[g]
            # Positive margins should increase a good's attractiveness;
            # inventory surpluses should reduce it. Normalize to prevent
            # excessively large z-values from destabilizing shares.
            norm_margin = margin / max(1.0, abs(self.c.get(g, 1.0)), abs(self.p.get(g, 1.0)))
            norm_delta_I = delta_I / (1.0 + abs(self.y.get(g, 0.0)))
            z_val = self.alpha_m * norm_margin - self.alpha_I * norm_delta_I
            z[g] = float(np.clip(z_val, -10.0, 10.0))

        z_bar = sum(self.s[g] * z[g] for g in self.GOODS)

        for g in self.GOODS:
            self.s[g] += self.eta_s * (z[g] - z_bar) * self.s[g]

        # Prevent degenerate total (zero or non-finite) by clipping then renormalizing
        for g in self.GOODS:
            if not np.isfinite(self.s[g]):
                self.s[g] = S_MIN
            # ensure non-negative and at least S_MIN
            if self.s[g] < S_MIN:
                self.s[g] = S_MIN

        total = sum(self.s.values())
        if total <= 0 or not np.isfinite(total):
            # fallback to uniform shares
            uniform = 1.0 / len(self.GOODS)
            for g in self.GOODS:
                self.s[g] = uniform
        else:
            for g in self.GOODS:
                self.s[g] /= total

    # --- convert shares into production levels ---

    def update_production_levels(self):
        L_total = sum(h.L for h in self.model.households)
        K_total = sum(h.K for h in self.model.households)
        Q = self.production_capacity(L_total, K_total)

        for g in self.GOODS:
            self.y[g] = self.s[g] * Q

    # --- profit and factor prices ---

    def compute_profit(self):
        # Firm receives net prices only on actual sales
        revenue = sum(float(self.p[g]) * float(self.sales.get(g, 0.0)) for g in self.GOODS)
        L_total = sum(h.L for h in self.model.households)
        K_total = sum(h.K for h in self.model.households)
        factor_cost = self.w * L_total + self.r * K_total
        return revenue - factor_cost

    def update_factor_prices(self):
        profit = self.compute_profit()
        # Stabilized factor price updates: bound the impact of large profits
        # by scaling and applying a bounded relative update (tanh). This
        # prevents extreme jumps when profits (or revenues) are large.
        L_total = sum(h.L for h in self.model.households)
        K_total = sum(h.K for h in self.model.households)
        revenue = sum(abs(float(self.p[g]) * float(self.sales.get(g, 0.0))) for g in self.GOODS)
        factor_cost = self.w * L_total + self.r * K_total
        scale = max(1.0, revenue, abs(profit), abs(factor_cost))

        delta_w = self.eta_w * self.w * np.tanh(profit / (scale + 1e-12)) * self.beta_L
        delta_r = self.eta_r * self.r * np.tanh(profit / (scale + 1e-12)) * self.beta_K

        self.w += float(delta_w)
        self.r += float(delta_r)
        self.w = max(1e-4, self.w)
        self.r = max(1e-4, self.r)

    # --- Mesa step ---

    def step(self):
        # 1. Compute profit based on last period’s demand
        self.update_factor_prices()

        # 2. Settle sales and update inventories based on available supply
        self.settle_sales_and_update_inventories()

        # 3. Update net prices toward zero margins and according to unmet demand
        self.update_goods_prices()

        # 4. Update gross prices from tariff
        self.update_gross_prices_from_tariff()

        # 5. Update production shares
        self.update_production_shares()

        # 6. Convert shares into actual production for the next period
        self.update_production_levels()

        # 7. Update factor prices toward zero aggregate profit (based on realized sales)
        self.update_factor_prices()



class Government(Agent):
    def __init__(self, model, tau, start, end):
        super().__init__(model)
        self.tau = tau
        self.start = start
        self.end = end
        self.revenue_buffer = 0.0
        self.transfers = {}  # household_id -> transfer for current period

    def collect_tariff(self):
        t = getattr(self.model, "time", 0)
        if self.start is None or (t < self.start) or (self.end is not None and t > self.end):
            self.revenue_buffer = 0.0
            return

        firm = self.model.firm
        # collect tariff only on actual import sales (net price * sold quantity)
        rev_xm = float(firm.p.get("xm", 0.0)) * float(firm.sales.get("xm", 0.0))
        rev_ym = float(firm.p.get("ym", 0.0)) * float(firm.sales.get("ym", 0.0))
        self.revenue_buffer = float(self.tau) * (rev_xm + rev_ym)

    def distribute_transfers(self):
        households = self.model.households
        if not households:
            return
        per_household = self.revenue_buffer / len(households)
        self.transfers = {h.unique_id: per_household for h in households}
        self.revenue_buffer = 0.0

    def transfer_for(self, household):
        return self.transfers.get(household.unique_id, 0.0)

    def step(self):
        # 1. Collect tariff based on last period's firm sales
        self.collect_tariff()
        # 2. Distribute in this period
        self.distribute_transfers()

