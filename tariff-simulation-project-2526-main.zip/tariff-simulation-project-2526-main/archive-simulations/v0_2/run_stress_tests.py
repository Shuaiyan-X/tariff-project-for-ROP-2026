from pathlib import Path
from run_cc import run_seed

outdir_base = Path("results/stress_tests")

for seed in range(1, 31):
    for scenario in ("homogeneous", "heterogeneous"):
        out = outdir_base / scenario
        print(f"Running seed {seed} scenario {scenario} -> {out}")
        try:
            run_seed(seed, scenario, out, num_households=50, num_steps=200)
        except ZeroDivisionError as zde:
            print(f"ZERO DIVISION at seed={seed} scenario={scenario}: {zde}")
            raise
        except Exception as e:
            print(f"ERROR seed={seed} scenario={scenario}: {e}")
            raise
