from mesa import Model
from mesa.datacollection import DataCollector
from agents import Household, Firm, Government

class TariffModel(Model):
    def __init__(self,
                 N_households,
                 household_param_dist,
                 firm_params,
                 gov_params,
                 seed=None):
        super().__init__(seed=seed)

        # simulation time (used instead of a Mesa scheduler)
        self.time = 0

        # legacy agent list used by the minimal schedule (kept in sync
        # with Mesa's internal agent registration). Use a different name to
        # avoid shadowing Mesa's internal `_agents` dict.
        self._legacy_agents = []

        # Create firm and government (Mesa Agent will call register_agent)
        self.firm = Firm(self, **firm_params)

        # Create government
        self.gov  = Government(self, **gov_params)

        # Create households
        self.households = []
        for i in range(N_households):
            params = household_param_dist(i)  # function that draws hetero params
            h = Household(self, **params)
            self.households.append(h)

        # Minimal schedule-like object so DataCollector can find agents and time
        class _Sched:
            pass

        self.schedule = _Sched()
        # point schedule.agents to our internal agent registry populated via register_agent
        self.schedule.agents = self._legacy_agents
        self.schedule.time = self.time

        # Data collector: collect prices, factor prices, aggregates, and agent-level variables
        self.datacollector = DataCollector(
            model_reporters={
                "avg_price_xd": lambda m: m.firm.p["xd"],
                "avg_price_xm": lambda m: m.firm.p["xm"],
                "avg_price_yd": lambda m: m.firm.p["yd"],
                "avg_price_ym": lambda m: m.firm.p["ym"],
                "wage": lambda m: m.firm.w,
                "rent": lambda m: m.firm.r,
                "total_output": lambda m: sum(m.firm.y.values()),
                "total_demand": lambda m: sum(m.firm.q.values()),
                "total_inventory": lambda m: sum(m.firm.I.values()),
                "profit": lambda m: m.firm.compute_profit(),
                # Nominal tariff parameter (unchanging parameter)
                "tau_param": lambda m: getattr(m.gov, "tau", None),
                # Whether tariff is active at current model time
                "tariff_active": lambda m: (m.time >= getattr(m.gov, "start", 0)) and (getattr(m.gov, "end", None) is None or m.time <= getattr(m.gov, "end")),
                # Effective tariff applied this period (0 if inactive)
                "tau_effective": lambda m: (getattr(m.gov, "tau", 0.0) if ((m.time >= getattr(m.gov, "start", 0)) and (getattr(m.gov, "end", None) is None or m.time <= getattr(m.gov, "end"))) else 0.0),
                "gov_revenue_buffer": lambda m: getattr(m.gov, "revenue_buffer", None),
                "total_sales": lambda m: sum(m.firm.sales.values()),
                "avg_transfer": lambda m: (sum(m.gov.transfers.values()) / len(m.gov.transfers)) if getattr(m.gov, "transfers", None) else 0.0,
                "price_level": lambda m: m.firm.get_price_level(),
            },
            agent_reporters={
                "agent_type": lambda a: type(a).__name__,
                "money": lambda a: getattr(a, "money", None),
                "xd": lambda a: getattr(a, "xd", None),
                "xm": lambda a: getattr(a, "xm", None),
                "yd": lambda a: getattr(a, "yd", None),
                "ym": lambda a: getattr(a, "ym", None),
                "L": lambda a: getattr(a, "L", None),
                "K": lambda a: getattr(a, "K", None),
                "utility": lambda a: a.inst_utility(getattr(a, "xd", 0.0), getattr(a, "xm", 0.0), getattr(a, "yd", 0.0), getattr(a, "ym", 0.0)) if hasattr(a, "inst_utility") else None,
                "profit": lambda a: a.compute_profit() if hasattr(a, "compute_profit") else None,
            }
        )

    def register_agent(self, agent):
        """Register agent using Mesa's registration, and keep local list synced.

        Mesa's Model.register_agent handles _all_agents, _agents_by_type and
        unique id assignment; delegate to it then append to our local list so
        existing `self.schedule.agents` remains populated.
        """
        super().register_agent(agent)
        # keep legacy list in sync for simple schedule access
        self._legacy_agents.append(agent)
    def step(self):

        # 1. Government distributes transfers from last period
        self.gov.distribute_transfers()

        # 2. Households act (consume, demand, update expectations)
        for h in self.households:
            h.step()

        # 3. Firm acts (observes demand, updates prices, production, factor prices)
        self.firm.step()

        # 4. Government collects tariff revenue from this period’s sales
        self.gov.collect_tariff()

        # 5. Advance time
        # Note: Mesa's Model wrapper increments `time` automatically before
        # calling this user-defined `step`. Do NOT increment `self.time` here
        # to avoid double-stepping. Keep the schedule view in sync.
        if hasattr(self, "schedule"):
            self.schedule.time = self.time

        # 6. Collect data
        self.datacollector.collect(self)
