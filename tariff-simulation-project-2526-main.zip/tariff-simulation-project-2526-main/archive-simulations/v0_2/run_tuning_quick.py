import runpy, sys
sys.path.insert(0, '.')
runpy.run_path('debug_scripts/tuning_quick.py', run_name='__main__')
