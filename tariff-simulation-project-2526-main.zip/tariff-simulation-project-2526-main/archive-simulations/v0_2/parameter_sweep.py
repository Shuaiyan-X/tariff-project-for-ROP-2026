"""
parameter_sweep.py

Randomized parameter search for TariffModel to find regions where:
 - net change in firm inventories -> 0
 - net change in net profits -> 0
 - household incomes do not collapse to 0

This script runs a set of randomized parameter draws, evaluates simple
stability metrics on the model output, and saves results to CSV.

Usage (example):
    python full-simulation/parameter_sweep.py --samples 40 --num-steps 400

The script is deliberately conservative with runtime defaults so you can
run a small quick-test and then increase `--samples` and `--num-steps`.
"""

import argparse
import json
import time
from pathlib import Path
import mesa

import importlib

import numpy as np
import pandas as pd

# TariffModel will be imported dynamically (allow switching to no-factor model)


def make_homogeneous_household_dist(L0=1.0, K0=1.0, n=0.0, s=0.0,
                                    theta=0.5, alpha=0.95, N_lookahead=1,
                                    lambda_p=1.0, lambda_w=1.0, lambda_r=1.0,
                                    dx=0.5, dy=0.5,
                                    sigma_x=1.0, sigma_y=1.0):
    const = dict(
        L0=float(L0), K0=float(K0), n=float(n), s=float(s),
        theta=float(theta), alpha=float(alpha), N=int(N_lookahead),
        lambda_p=float(lambda_p), lambda_w=float(lambda_w), lambda_r=float(lambda_r),
        dx=float(dx), dy=float(dy),
        sigma_x=float(sigma_x), sigma_y=float(sigma_y),
    )

    def dist(i):
        return const.copy()

    return dist


def make_heterogeneous_household_dist(rng, theta_loc=0.5, theta_scale=0.05,
                                      phi_loc=0.5, phi_scale=0.05, N_lookahead=1,
                                      lambda_p=1.0, lambda_w=1.0, lambda_r=1.0):
    def dist(i):
        theta = float(np.clip(rng.normal(theta_loc, theta_scale), 0.01, 0.99))
        phi = float(np.clip(rng.normal(phi_loc, phi_scale), 0.01, 0.99))
        return dict(
            L0=1.0, K0=1.0, n=0.0, s=0.0,
            theta=theta, alpha=0.95, N=int(N_lookahead),
            lambda_p=float(lambda_p), lambda_w=float(lambda_w), lambda_r=float(lambda_r),
            dx=phi, dy=phi,
            sigma_x=1.0, sigma_y=1.0,
        )

    return dist


def sample_parameters(rng):
    # log-uniform helpers
    def log_uniform(low, high):
        return float(10 ** rng.uniform(np.log10(low), np.log10(high)))

    firm = {
        'z': float(rng.uniform(0.5, 3.0)),
        'beta_L': float(rng.uniform(0.3, 0.7)),
        # beta_K set so that beta_L + beta_K = 1 (Cobb-Douglas-like)
        # caller will set beta_K = 1 - beta_L
        'np_price': float(log_uniform(1e-5, 1e-1)),
        'alpha_m': float(rng.uniform(0.0, 0.1)),
        'alpha_I': float(rng.uniform(0.0, 0.1)),
        'eta_s': float(rng.uniform(0.0, 0.1)),
        'eta_w': float(log_uniform(1e-5, 2e-1)),
        'eta_r': float(log_uniform(1e-5, 2e-1)),
        'eta_d': float(rng.uniform(0.0, 0.05)),
        'c_d': float(rng.uniform(0.5, 3.0)),
        'c_m': float(rng.uniform(0.5, 3.0)),
    }
    firm['beta_K'] = 1.0 - firm['beta_L']

    hh = {
        'theta': float(rng.uniform(0.2, 0.8)),
        'dx': float(rng.uniform(0.2, 0.8)),
        'dy': float(rng.uniform(0.2, 0.8)),
        'lambda_p': float(rng.uniform(0.0, 1.0)),
        'lambda_w': float(rng.uniform(0.0, 1.0)),
        'lambda_r': float(rng.uniform(0.0, 1.0)),
        'N_lookahead': int(rng.choice([1, 2, 3])),
    }

    gov = {
        'tau': float(rng.uniform(0.0, 0.2)),
        'start': 50,
        'end': None,
    }

    return firm, hh, gov


def compute_slope(y, window=50):
    y = np.asarray(y, dtype=float)
    if y.size == 0:
        return np.nan, np.nan
    w = int(min(window, max(3, y.size // 5)))
    ys = y[-w:]
    x = np.arange(len(ys), dtype=float)
    # linear fit
    try:
        a = np.polyfit(x, ys, 1)[0]
    except Exception:
        a = float('nan')
    return float(a), float(np.mean(ys))


def evaluate_run(model, model_df, household_dist, num_households, thresholds=None):
    # thresholds: dict of tolerances
    if thresholds is None:
        thresholds = {}
    inv_rel_tol = thresholds.get('inv_rel_tol', 1e-3)
    inv_abs_tol = thresholds.get('inv_abs_tol', 1e-4)
    profit_rel_tol = thresholds.get('profit_rel_tol', 1e-3)
    profit_abs_tol = thresholds.get('profit_abs_tol', 1e-4)
    income_abs_min = thresholds.get('income_abs_min', 0.1)
    income_frac_min = thresholds.get('income_frac_min', 0.2)

    res = {}

    # total inventory and profit series
    inv_ts = model_df['total_inventory'].values if 'total_inventory' in model_df else np.array([])
    profit_ts = model_df['profit'].values if 'profit' in model_df else np.array([])

    inv_slope, inv_mean = compute_slope(inv_ts)
    profit_slope, profit_mean = compute_slope(profit_ts)

    res['inv_slope'] = inv_slope
    res['inv_mean'] = inv_mean
    res['profit_slope'] = profit_slope
    res['profit_mean'] = profit_mean

    # initial average household income (use the household_dist to get initial L0/K0)
    initial_incomes = []
    for i in range(num_households):
        d = household_dist(i)
        initial_incomes.append(1.0 * float(d.get('L0', 1.0)) + 1.0 * float(d.get('K0', 1.0)))
    initial_avg_income = float(np.mean(initial_incomes)) if initial_incomes else 0.0

    # final average household income from model state (use household compute_income())
    final_incomes = []
    for h in model.households:
        try:
            final_incomes.append(float(h.compute_income()))
        except Exception:
            # fallback: if household doesn't implement compute_income, approximate
            final_incomes.append(0.0)
    final_avg_income = float(np.mean(final_incomes)) if final_incomes else 0.0

    res['initial_avg_income'] = initial_avg_income
    res['final_avg_income'] = final_avg_income

    # stability checks
    def check_trend(slope, mean, rel_tol, abs_tol):
        if not np.isfinite(slope) or not np.isfinite(mean):
            return False
        allowed = max(rel_tol * max(1.0, abs(mean)), abs_tol)
        return abs(slope) <= allowed

    stable_inventory = check_trend(inv_slope, inv_mean, inv_rel_tol, inv_abs_tol)
    stable_profit = check_trend(profit_slope, profit_mean, profit_rel_tol, profit_abs_tol)
    income_ok = (final_avg_income >= max(income_abs_min, income_frac_min * max(1.0, initial_avg_income))) and np.isfinite(final_avg_income)

    res['stable_inventory'] = bool(stable_inventory)
    res['stable_profit'] = bool(stable_profit)
    res['income_ok'] = bool(income_ok)
    res['stable_all'] = bool(stable_inventory and stable_profit and income_ok)

    # quick sanity checks (no blowups)
    res['inv_max'] = float(np.nanmax(inv_ts) if inv_ts.size else np.nan)
    res['profit_max'] = float(np.nanmax(profit_ts) if profit_ts.size else np.nan)

    return res


def run_one_sample(seed, firm_params, hh_params, gov_params, scenario, num_households, num_steps, model_name='model'):
    rng = np.random.RandomState(int(seed))

    # construct household distribution
    if scenario == 'homogeneous':
        household_dist = make_homogeneous_household_dist(theta=hh_params['theta'], dx=hh_params['dx'], dy=hh_params['dy'],
                                                         N_lookahead=hh_params['N_lookahead'],
                                                         lambda_p=hh_params['lambda_p'], lambda_w=hh_params['lambda_w'], lambda_r=hh_params['lambda_r'])
    else:
        household_dist = make_heterogeneous_household_dist(rng, theta_loc=hh_params['theta'], theta_scale=0.05,
                                                           phi_loc=hh_params['dx'], phi_scale=0.05,
                                                           N_lookahead=hh_params['N_lookahead'],
                                                           lambda_p=hh_params['lambda_p'], lambda_w=hh_params['lambda_w'], lambda_r=hh_params['lambda_r'])

    firm_args = firm_params.copy()
    # ensure beta_K present
    if 'beta_K' not in firm_args:
        firm_args['beta_K'] = 1.0 - float(firm_args.get('beta_L', 0.5))

    # import model class dynamically so we can run the no-factor variant
    try:
        mod = importlib.import_module(model_name)
        TariffModel = getattr(mod, 'TariffModel')
    except Exception as e:
        # fallback to the default model module
        mod = importlib.import_module('model')
        TariffModel = getattr(mod, 'TariffModel')

    model = TariffModel(N_households=int(num_households), household_param_dist=household_dist, firm_params=firm_args, gov_params=gov_params, seed=int(seed))

    for t in range(int(num_steps)):
        model.step()

    model_df = model.datacollector.get_model_vars_dataframe()

    return model, model_df, household_dist


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--samples', type=int, default=40)
    parser.add_argument('--num-steps', type=int, default=400)
    parser.add_argument('--num-households', type=int, default=100)
    parser.add_argument('--outdir', type=str, default='results/sweep')
    parser.add_argument('--scenario', type=str, default='homogeneous', choices=['homogeneous', 'heterogeneous'])
    parser.add_argument('--model', type=str, default='full', choices=['full', 'no_factor'], help='Which model module to use (full=model, no_factor=model_no_factor)')
    parser.add_argument('--seed0', type=int, default=0)
    parser.add_argument('--save-top', type=int, default=3, help='How many full runs to save (model csvs)')
    args = parser.parse_args()

    outdir = Path(args.outdir)
    outdir.mkdir(parents=True, exist_ok=True)

    results = []
    saved_details = []

    for s in range(args.samples):
        seed = args.seed0 + s
        rng = np.random.RandomState(seed)
        firm_params, hh_params, gov_params = sample_parameters(rng)

        # pass load balancing: ensure small enough steps for testing
        try:
            start = time.time()
            model, model_df, household_dist = run_one_sample(seed, firm_params, hh_params, gov_params, args.scenario, args.num_households, args.num_steps, model_name=('model' if args.model == 'full' else 'model_no_factor'))
            elapsed = time.time() - start

            metrics = evaluate_run(model, model_df, household_dist, args.num_households)

            row = {
                'sample': int(s), 'seed': int(seed), 'scenario': args.scenario,
                'num_households': int(args.num_households), 'num_steps': int(args.num_steps),
                'elapsed_s': float(elapsed),
            }
            row['model_choice'] = args.model
            # flatten firm/hh/gov params
            row.update({f'firm_{k}': v for k, v in firm_params.items()})
            row.update({f'hh_{k}': v for k, v in hh_params.items()})
            row.update({f'gov_{k}': v for k, v in gov_params.items()})
            row.update(metrics)

            results.append(row)

            if metrics.get('stable_all'):
                saved_details.append(row)

            print(f"Sample {s}/{args.samples-1} seed={seed} stable={metrics.get('stable_all')} elapsed={elapsed:.2f}s")

        except Exception as e:
            print(f"ERROR sample={s} seed={seed}: {e}")
            results.append({'sample': int(s), 'seed': int(seed), 'error': str(e)})

    results_df = pd.DataFrame(results)
    results_csv = outdir / 'sweep_results.csv'
    results_df.to_csv(results_csv, index=False)

    # save candidates
    candidates_df = results_df[results_df['stable_all'] == True]
    candidates_csv = outdir / 'stable_candidates.csv'
    candidates_df.to_csv(candidates_csv, index=False)

    # Save a small summary JSON
    summary = {
        'samples': int(args.samples),
        'stable_count': int(len(candidates_df)),
        'saved_details': len(saved_details),
    }
    with open(outdir / 'summary.json', 'w') as f:
        json.dump(summary, f, indent=2)

    print('\nSweep complete. Results saved to:', str(results_csv))
    print('Stable candidates:', len(candidates_df))


if __name__ == '__main__':
    main()
