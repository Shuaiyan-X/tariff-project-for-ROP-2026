"""
Run comparative simulations across random seeds and save data.

Creates homogeneous and heterogeneous scenarios and stores datacollector outputs.
"""

from model import TariffModel
import numpy as np
import pandas as pd
from pathlib import Path
import json
import os


def make_homogeneous_household_dist(theta=0.5, dx=0.5, dy=0.5, N_lookahead=2):
	const = dict(
		L0=1.0, K0=1.0, n=0.04, s=0.04,
		theta=float(theta), alpha=0.95, N=int(N_lookahead),
		lambda_p=0.5, lambda_w=0.5, lambda_r=0.5,
		dx=float(dx), dy=float(dy),
		sigma_x=1.0, sigma_y=1.0
	)

	def dist(i):
		return const.copy()

	return dist


def make_heterogeneous_household_dist(rng, theta_loc=0.5, theta_scale=0.05, phi_loc=0.5, phi_scale=0.05, N_lookahead=2):
	def dist(i):
		theta = float(np.clip(rng.normal(theta_loc, theta_scale), 0.01, 0.99))
		phi = float(np.clip(rng.normal(phi_loc, phi_scale), 0.01, 0.99))
		return dict(
			L0=1.0, K0=1.0, n=0.0, s=0.0,
			theta=theta, alpha=0.95, N=int(N_lookahead),
			lambda_p=0.5, lambda_w=0.5, lambda_r=0.5,
			dx=phi, dy=phi,
			sigma_x=1.0, sigma_y=1.0
		)

	return dist


def run_seed(seed, scenario, out_dir, num_households=100, num_steps=200):
	rng = np.random.RandomState(seed)

	# Government parameters: collect tariffs from time 100 onward
	gov_params = {"tau": 0.1, "start": 100, "end": None}

	# Base firm parameters with defaults
	base_firm = dict(
		z=2.0, beta_L=0.5, beta_K=0.5,
		np_price=0.01, alpha_m=0.01, alpha_I=0.01, eta_s=0.01,
		eta_w=0.01, eta_r=0.01, c_d=2.0, c_m=2.0
	)

	if scenario == "homogeneous":
		household_dist = make_homogeneous_household_dist(theta=0.5, dx=0.5, dy=0.5, N_lookahead=2)
		firm_params = base_firm.copy()
	else:
		household_dist = make_heterogeneous_household_dist(rng)
		firm_params = base_firm.copy()
		# draw heterogeneous firm update speeds around 0.01
		firm_params["eta_w"] = float(max(1e-4, rng.normal(0.01, 0.002)))
		firm_params["eta_r"] = float(max(1e-4, rng.normal(0.01, 0.002)))

	# Instantiate model with deterministic seeds
	model = TariffModel(
		N_households=num_households,
		household_param_dist=household_dist,
		firm_params=firm_params,
		gov_params=gov_params,
		seed=int(seed),
	)

	# Run
	for t in range(num_steps):
		model.step()

	# Collect and save
	model_df = model.datacollector.get_model_vars_dataframe()
	agent_df = model.datacollector.get_agent_vars_dataframe()

	out_dir = Path(out_dir)
	out_dir.mkdir(parents=True, exist_ok=True)

	model_df.to_csv(out_dir / f"seed_{seed:03d}_model.csv")
	agent_df.to_csv(out_dir / f"seed_{seed:03d}_agents.csv")

	meta = {
		"seed": int(seed),
		"scenario": scenario,
		"num_households": int(num_households),
		"num_steps": int(num_steps),
		"firm_params": firm_params,
		"gov_params": gov_params,
	}
	with open(out_dir / f"seed_{seed:03d}_meta.json", "w") as f:
		json.dump(meta, f, indent=2)

	return out_dir / f"seed_{seed:03d}_model.csv"


def main():
	seeds = list(range(1, 11))
	num_steps = 200
	num_households = 100

	base_results = Path(__file__).resolve().parent / "results_ee"
	for seed in seeds:
		for scenario in ("homogeneous", "heterogeneous"):
			out = base_results / scenario
			print(f"Running seed {seed} scenario {scenario} -> {out}")
			run_seed(seed, scenario, out, num_households=num_households, num_steps=num_steps)


if __name__ == "__main__":
	main()
