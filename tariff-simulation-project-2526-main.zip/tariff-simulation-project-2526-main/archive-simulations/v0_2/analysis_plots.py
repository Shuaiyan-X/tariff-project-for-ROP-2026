"""
Analyze sweep CSVs and produce scatter plots:
 - inv_slope vs inv_mean
 - profit_slope vs profit_mean
 - final_avg_income vs initial_avg_income

Saves plots and a small JSON summary to `results/analysis_pre_mod/`.
"""
import os
from pathlib import Path
import json

import numpy as np
import pandas as pd
import matplotlib.pyplot as plt


ROOT = Path(__file__).resolve().parent
OUT = ROOT / 'results' / 'analysis_pre_mod'
OUT.mkdir(parents=True, exist_ok=True)

files = []
results_root = ROOT / 'results'
for sweep_dir in results_root.glob('sweep*'):
    p = sweep_dir / 'sweep_results.csv'
    if p.exists():
        df = pd.read_csv(p)
        # keep the sweep directory label so we can distinguish no-factor runs
        df['scenario'] = sweep_dir.name
        files.append(df)

if not files:
    print('No sweep CSVs found in results/*/sweep*/sweep_results.csv')
    raise SystemExit(1)

df = pd.concat(files, ignore_index=True)

pairs = [
    ('inv_slope', 'inv_mean', 'Inventory slope vs mean'),
    ('profit_slope', 'profit_mean', 'Profit slope vs mean'),
    ('initial_avg_income', 'final_avg_income', 'Final vs Initial Average Income'),
]

summary = {}
for xcol, ycol, title in pairs:
    if xcol not in df or ycol not in df:
        print(f'Missing columns {xcol} or {ycol} in data')
        continue
    sub = df[[xcol, ycol, 'scenario']].dropna()

    # compute Pearson and Spearman
    try:
        pearson = float(sub[xcol].corr(sub[ycol]))
    except Exception:
        pearson = None
    try:
        spearman = float(sub[xcol].rank().corr(sub[ycol].rank()))
    except Exception:
        spearman = None

    summary[f'{xcol}_vs_{ycol}'] = {'pearson': pearson, 'spearman': spearman, 'n': int(len(sub))}

    plt.figure(figsize=(6, 4))
    for scenario, g in sub.groupby('scenario'):
        plt.scatter(g[xcol], g[ycol], label=scenario, alpha=0.7)
    plt.axhline(0, color='k', lw=0.5)
    plt.axvline(0, color='k', lw=0.5)
    plt.xlabel(xcol)
    plt.ylabel(ycol)
    plt.title(title)
    plt.legend()
    plt.tight_layout()
    outp = OUT / f'{xcol}_vs_{ycol}.png'
    plt.savefig(outp)
    plt.close()
    print('Saved', outp)

# save summary
with open(OUT / 'correlations.json', 'w') as f:
    json.dump(summary, f, indent=2)

print('Summary:', json.dumps(summary, indent=2))
