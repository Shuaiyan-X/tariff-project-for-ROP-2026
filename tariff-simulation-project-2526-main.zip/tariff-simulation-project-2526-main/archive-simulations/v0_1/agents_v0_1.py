import mesa
import numpy as np

def ces_price_index(p_d: float, p_m: float, theta: float, sigma: float) -> float:
    """
    Armington CES price index for two varieties: domestic (d) and import (m).
    P = (theta p_d^(1-sigma) + (1-theta) p_m^(1-sigma))^(1/(1-sigma))
    """
    if sigma == 1:
        # Cobb-Douglas limit: P = p_d^theta * p_m^(1-theta)
        return (p_d ** theta) * (p_m ** (1 - theta))
    inner = theta * (p_d ** (1 - sigma)) + (1 - theta) * (p_m ** (1 - sigma))
    return inner ** (1.0 / (1.0 - sigma))

def ces_expenditure_shares(p_d: float, p_m: float, theta: float, sigma: float):
    """
    Returns (s_d, s_m) expenditure shares that sum to 1 under CES.
    """
    if sigma == 1:
        return theta, 1 - theta
    P = ces_price_index(p_d, p_m, theta, sigma)
    s_d = theta * (p_d / P) ** (1 - sigma)
    s_m = (1 - theta) * (p_m / P) ** (1 - sigma)
    # numerical cleanup
    total = s_d + s_m
    if total <= 0:
        return 0.5, 0.5
    return s_d / total, s_m / total

class Consumer(mesa.Agent):
    """
    Consumer with Armington (domestic vs import) CES preferences.
    Keeps original "work -> choose -> consume" flow, but replaces per-firm
    optimization with closed-form CES demands.

    Utility each period is u(C)=C^alpha where C is the CES composite.
    """
    def __init__(self, model: mesa.Model):
        super().__init__(model)
        # static parameters
        self.income = self.model.income()
        self.alpha = self.model.alpha()
        self.theta = self.model.theta()
        self.sigma = self.model.sigma()

        # dynamic parameters
        self.utility = 0.0
        self.consume_queue = []  # list[dict[firm_id, quantity]]
        self.money = 0.0
        # optional diagnostics
        self.last_cd = 0.0
        self.last_cm = 0.0

    def work(self):
        self.money += self.income

    def _pick_cheapest_firm(self, origin: str, effective_prices: dict):
        """
        Pick the cheapest firm among those with the given origin.
        effective_prices maps firm_id -> effective price faced by consumer.
        """
        candidates = []
        for firm_id, firm in self.model.firms.items():
            if firm.origin == origin:
                candidates.append(firm_id)
        if not candidates:
            return None
        return min(candidates, key=lambda fid: effective_prices[fid])

    def choose_consumption(self):
        """
        Armington choice: allocate budget between domestic and import using CES shares.
        To keep your original structure, within each origin we buy from the cheapest firm.
        """
        # build effective prices (tariff only applies to import)
        effective_prices = {}
        for firm_id, p in self.model.prices.items():
            firm = self.model.firms[firm_id]
            if firm.origin == "import":
                effective_prices[firm_id] = p * (1.0 + self.model.tau)
            else:
                effective_prices[firm_id] = p

        # choose representative domestic/import firm (cheapest within origin)
        dom_id = self._pick_cheapest_firm("domestic", effective_prices)
        imp_id = self._pick_cheapest_firm("import", effective_prices)

        # if one side is missing, fall back to the other (still valid)
        own_demand = {fid: 0.0 for fid in self.model.prices.keys()}
        I = self.money
        if I <= 0:
            self.consume_queue.append(own_demand)
            self.last_cd, self.last_cm = 0.0, 0.0
            return

        if dom_id is None and imp_id is None:
            self.consume_queue.append(own_demand)
            self.last_cd, self.last_cm = 0.0, 0.0
            return

        if dom_id is None:
            # all spending on imports
            p_m = effective_prices[imp_id]
            cm = I / p_m
            own_demand[imp_id] = cm
            self.last_cd, self.last_cm = 0.0, cm
            self.consume_queue.append(own_demand)
            return

        if imp_id is None:
            # all spending on domestic
            p_d = effective_prices[dom_id]
            cd = I / p_d
            own_demand[dom_id] = cd
            self.last_cd, self.last_cm = cd, 0.0
            self.consume_queue.append(own_demand)
            return

        # both exist: Armington CES allocation
        p_d = effective_prices[dom_id]
        p_m = effective_prices[imp_id]
        s_d, s_m = ces_expenditure_shares(p_d, p_m, self.theta, self.sigma)

        cd = (s_d * I) / p_d
        cm = (s_m * I) / p_m

        own_demand[dom_id] += cd
        own_demand[imp_id] += cm

        self.last_cd, self.last_cm = cd, cm
        self.consume_queue.append(own_demand)

    def consume(self):
        """
        Buy chosen quantities. Keeps your original 'subtract supply' logic,
        but since firms currently produce to match aggregate demand, rationing
        should rarely bind.
        """
        own_demand = self.consume_queue.pop(0)
        cd = 0.0
        cm = 0.0
        for firm_id, q in own_demand.items():
            if q <= 0:
                continue
            firm = self.model.firms[firm_id]
            # effective price includes tariff for imports
            price_eff = self.model.prices[firm_id] * (1.0 + self.model.tau) if firm.origin == "import" else self.model.prices[firm_id]
            bought = min(q, self.model.supply.get(firm_id, 0.0))
            self.money -= bought * price_eff
            self.model.supply[firm_id] = self.model.supply.get(firm_id, 0.0) - bought
            if firm.origin == "domestic":
                cd += bought
            else:
                cm += bought

        # CES composite consumption -> utility
        if cd == 0 and cm == 0:
            C = 0.0
        else:
            if self.sigma == 1:
                # Cobb-Douglas limit composite (up to monotone transform)
                C = (cd ** self.theta) * (cm ** (1 - self.theta)) if (cd > 0 and cm > 0) else (cd + cm)
            else:
                C = (self.theta * (cd ** ((self.sigma - 1) / self.sigma)) +
                     (1 - self.theta) * (cm ** ((self.sigma - 1) / self.sigma))) ** (self.sigma / (self.sigma - 1))

        util_gain = (C ** self.alpha) if C > 0 else 0.0
        self.utility += util_gain
        return {"C": C, "Cd": cd, "Cm": cm, "utility": util_gain}

    def reset(self):
        # keep original default behavior: clear period utility, optionally clear money
        self.utility = 0.0
        if not getattr(self.model, "carry_wealth", False):
            self.money = 0.0
        self.consume_queue = []

class Firm(mesa.Agent):
    """
    Firm agent. Kept your core logic:
    - post a price
    - produce to match demand (for now)
    - compute profit and update price based on profit change

    Added: origin in {"domestic","import"} for Armington.
    """
    def __init__(self, model: mesa.Model,
                 origin="domestic",
                 ):
        super().__init__(model)
        self.origin = origin
        self.cost_params = self.model.cost_params()
        self.adjust_rate = self.model.adjust_rate()
        self.fixed_cost = self.model.fixed_cost()
        self.money = 0.0
        self.price = self.model.price()
        self.profit = [0.0, 0.0]

    def produce(self, demand):
        firm_demand = float(demand.get(self.unique_id, 0.0))
        firm_supply = firm_demand  # still clears demand in this version
        revenue = self.price * firm_supply
        cost = 0.5 * self.cost_params[0] * firm_supply ** 2 + self.cost_params[1] * firm_supply
        if firm_supply != 0:
            cost += self.fixed_cost
        profit = revenue - cost
        self.money += profit
        self.profit[0] = profit
        return firm_supply

    def update_prices(self):
        if self.profit[0] > self.profit[1]:
            self.price *= (1.0 + self.adjust_rate)
        else:
            self.price *= (1.0 - self.adjust_rate)
        self.profit[1] = self.profit[0]

    def reset(self):
        if not getattr(self.model, "carry_firm_cash", False):
            self.money = 0.0
