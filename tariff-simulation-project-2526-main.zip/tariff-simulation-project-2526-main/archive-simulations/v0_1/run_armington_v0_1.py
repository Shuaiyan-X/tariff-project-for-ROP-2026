# ============================================================
# Run script for Armington upgrade (model_v0_1 / agents_v0_1)
#
# 1) Confirms import path
# 2) Initializes the Armington model (domestic vs import + tariff schedule)
# 3) Runs the simulation for T periods
# 4) Extracts model-level time series and agent-level panel data
# 5) Splits agents into Firm vs Consumer tables
# 6) Saves CSV outputs and prints quick previews
# ============================================================

import model_v0_1
import numpy as np
print("IMPORTING FROM:", model_v0_1.__file__)

from model_v0_1 import Model

# ------------------------------------------------------------
# 0) Define distributions for the varied model
# ------------------------------------------------------------

# consumer parameter distributions
theta_dist = lambda: np.random.uniform(0.0, 1.0)
sigma_dist = lambda: (np.random.exponential(scale=1.0) + 1.0)
alpha_dist = lambda: np.random.uniform(0.0, 1.0)
income_dist = lambda: max(50.0, np.random.normal(loc=100.0, scale=10.0))

# firm parameter distributions
price_dist = lambda: max(0.5, np.random.normal(loc=2.0, scale=0.5))
fcost_dist = lambda: max(1.0, np.random.normal(loc=3.0, scale=1.0))
adjrate_dist = lambda: np.random.uniform(0.0, 0.15)
def cost_param_dist():
      coef1 = max(0.5, np.random.normal(loc=2.0, scale=0.5))
      coef2 = max(0.1, np.random.normal(loc=0.8, scale=0.2))
      return (coef2, coef1)

# ------------------------------------------------------------
# 1) Initialize the model (adjust params here)
# ------------------------------------------------------------

m = Model(seed=1) # default instantiation of model
m_var = Model(seed=1,
              firm_num_domestic=6,
              firm_num_import=7,
              # consumer params
              theta = theta_dist,
              sigma = sigma_dist,
              alpha = alpha_dist,
              income = income_dist,
              # firm params
              price = price_dist,
              fixed_cost = fcost_dist,
              adjust_rate=adjrate_dist,
              cost_params=cost_param_dist
              )

# ------------------------------------------------------------
# 2) Run the simulation for T time steps (periods)
# ------------------------------------------------------------
T = 50
for t in range(T):
    m.step()
    m_var.step()

print("Simulations finished.")

# ------------------------------------------------------------
# 3) Get model-level data (one row per time step)
# ------------------------------------------------------------
df_model = m.datacollector.get_model_vars_dataframe()
df_var_model = m_var.datacollector.get_model_vars_dataframe()

print("\nModel-level data preview:")
print(df_model.head())
print(df_var_model.head())

# ------------------------------------------------------------
# 4) Get agent-level data (panel: one row per agent per time step)
# reset_index() converts Step and AgentID from index into columns
# ------------------------------------------------------------
df_agent = m.datacollector.get_agent_vars_dataframe().reset_index()
df_var_agent = m_var.datacollector.get_agent_vars_dataframe().reset_index()

print("\nAgent columns:")
print(df_agent.columns.tolist())
print(df_var_agent.columns.tolist())

# ------------------------------------------------------------
# 5) Split the agent panel by agent type
# ------------------------------------------------------------
df_firm = df_agent[df_agent["type"] == "Firm"].copy()
df_cons = df_agent[df_agent["type"] == "Consumer"].copy()

df_var_firm = df_var_agent[df_var_agent["type"] == "Firm"].copy()
df_var_cons = df_var_agent[df_var_agent["type"] == "Consumer"].copy()

# Keep only the most relevant columns for each type
firm_cols = ["Step", "AgentID", "origin", "firm_price", "firm_profit", "money"]
cons_cols = ["Step", "AgentID", "cons_utility", "last_Cd", "last_Cm", "money"]

# If some columns are missing due to reporter names, comment these out
df_firm = df_firm[firm_cols]
df_cons = df_cons[cons_cols]

df_var_firm = df_var_firm[firm_cols]
df_var_cons = df_var_cons[cons_cols]

# ------------------------------------------------------------
# 6) Save outputs to CSV files
# ------------------------------------------------------------
save_directory = "archive-simulations/v0_1"

df_model.to_csv(f"{save_directory}/model_data_v0_1.csv", index=False)
df_firm.to_csv(f"{save_directory}/firm_data_v0_1.csv", index=False)
df_cons.to_csv(f"{save_directory}/consumer_data_v0_1.csv", index=False)

df_var_model.to_csv(f"{save_directory}/model_var_data_v0_1.csv", index=False)
df_var_firm.to_csv(f"{save_directory}/firm_var_data_v0_1.csv", index=False)
df_var_cons.to_csv(f"{save_directory}/consumer_var_data_v0_1.csv", index=False)

print("\nSaved simulation files.")

# ------------------------------------------------------------
# 7) Quick sanity checks (print previews)
# ------------------------------------------------------------
print("\nFirm preview (first 5 rows):")
print(df_firm.head())

print("\nFirm preview (last 5 rows):")
print(df_firm.tail())

print("\nConsumer preview (first 5 rows):")
print(df_cons.head())

print("\nConsumer preview (last 5 rows):")
print(df_cons.tail())

print("\n Variation Model Stuf:")

print("\nFirm preview (first 5 rows):")
print(df_var_firm.head())

print("\nFirm preview (last 5 rows):")
print(df_var_firm.tail())

print("\nConsumer preview (first 5 rows):")
print(df_var_cons.head())

print("\nConsumer preview (last 5 rows):")
print(df_var_cons.tail())

# ------------------------------------------------------------
# 8) Extra checks (optional): verify sizes
# ------------------------------------------------------------
print("\nRow counts:")
print("Firm rows:", len(df_firm))
print("Consumer rows:", len(df_cons))
