import mesa
import numpy as np
from agents_v0_1 import Consumer, Firm
from mesa.datacollection import DataCollector

class Model(mesa.Model):
    """
    Armington-ready Mesa model (upgrade of your v0_0):

    - Two origins of supply: domestic vs import firms
    - Consumers allocate spending between domestic/import using CES Armington demand
    - Tariff shock schedule: import prices are multiplied by (1+tau_t)
    - Keeps your original multi-stage step ordering and firm price updating rule

    All inputs to the class initialization are callables (as denoted by lambda),
    which allows for distributions and other functions to determine agent
    parameters.
    """
    def __init__(
        self, 
        # initial agent counts (fixed ints)
        consumer_num=100,
        firm_num_domestic=1,
        firm_num_import=1,
        seed=None,
        # Armington params (consumer side, accepts float distributions)
        theta=lambda:0.6,
        sigma=lambda:4.0,
        alpha=lambda:0.67,
        income=lambda:100.0,
        # Armington param (firm side, accepts float distributions)
        price=lambda:2.0,
        fixed_cost=lambda:3.0,
        adjust_rate=lambda:0.05,
        cost_params=lambda:(1.0,2.0), # callable must return (float, float)
        # tariff schedule params, use distributions for random tariffs
        tau_base=lambda:0.0,
        tau_shock=lambda:0.25,
        shock_start=lambda:10, # make sure callable returns int
        shock_end=lambda:30, # make sure callable returns int
        # dynamics options
        carry_wealth=False,
        carry_firm_cash=False,
    ):
        super().__init__(seed=seed)

        # draw model-level parameters from callables
        self.num_consumers = consumer_num
        self.num_firms_domestic = firm_num_domestic
        self.num_firms_import = firm_num_import
        self.num_firms = self.num_firms_domestic + self.num_firms_import

        # Armington parameters (consumer)
        self.theta = theta
        self.sigma = sigma
        self.alpha = alpha
        self.income = income

        # Armington parameters (firm)
        self.price = price
        self.fixed_cost = fixed_cost
        self.adjust_rate = adjust_rate
        self.cost_params = cost_params

        # tariff schedule
        self.tau_base = tau_base()
        self.tau_shock = tau_shock()
        self.shock_start = shock_start()
        self.shock_end = max(self.shock_start + 1, shock_end())
        self.tau = self.tau_base

        # behavior flags
        self.carry_wealth = carry_wealth
        self.carry_firm_cash = carry_firm_cash

        # create agents (keep your create_agents approach)
        Firm.create_agents(model=self, n=self.num_firms_domestic, origin="domestic")
        Firm.create_agents(model=self, n=self.num_firms_import, origin="import")
        Consumer.create_agents(model=self, n=self.num_consumers,)

        # convenient lookup for firms by id
        self.firms = {a.unique_id: a for a in self.agents if isinstance(a, Firm)}

        # global economic data structures (dynamic)
        self.prices = {}
        self.demand = {}
        self.supply = {}

        # aggregates
        self.total_production = 0.0
        self.avg_price = 0.0
        self.avg_utility = 0.0
        self.import_share_value = 0.0
        self.import_share_qty = 0.0
        self.tau_revenue = 0.0

        self.datacollector = DataCollector(
            model_reporters={
                "tau": lambda m: m.tau,
                "avg_price": lambda m: m.avg_price,
                "total_production": lambda m: m.total_production,
                "avg_utility": lambda m: m.avg_utility,
                "import_share_value": lambda m: m.import_share_value,
                "import_share_qty": lambda m: m.import_share_qty,
                "tariff_revenue": lambda m: m.tau_revenue,
                "num_consumers": lambda m: m.num_consumers,
                "num_firms": lambda m: m.num_firms,
            },
            agent_reporters={
                "type": lambda a: type(a).__name__,
                "origin": lambda a: a.origin if isinstance(a, Firm) else "",
                "firm_price": lambda a: a.price if isinstance(a, Firm) else np.nan,
                "firm_profit": lambda a: a.profit[0] if isinstance(a, Firm) else np.nan,
                "cons_utility": lambda a: a.utility if isinstance(a, Consumer) else np.nan,
                "money": lambda a: getattr(a, "money", np.nan),
                "last_Cd": lambda a: a.last_cd if isinstance(a, Consumer) else np.nan,
                "last_Cm": lambda a: a.last_cm if isinstance(a, Consumer) else np.nan,
            },
        )

    def _update_tariff(self):
        t = self.steps  # mesa tracks steps
        if self.shock_start <= t < self.shock_end:
            self.tau = self.tau_base + self.tau_shock
        else:
            self.tau = self.tau_base

    def step(self):
        """
        One full period:
        0) Update policy (tariff)
        1) Consumers work()
        2) Firms post prices -> model collects prices
        3) Consumers choose_consumption() (Armington)
        4) Model aggregates demand
        5) Firms produce()
        6) Consumers consume()
        7) Compute aggregates + collect
        8) Firms update prices
        9) Reset per-tick containers + agent reset (keeps your pattern)
        """
        # 0) policy
        self._update_tariff()

        # 1) consumers work
        for agent in self.agents:
            if isinstance(agent, Consumer):
                agent.work()

        # 2) collect prices from firms
        self.prices = {
            agent.unique_id: agent.price
            for agent in self.agents
            if isinstance(agent, Firm)
        }

        # 3) consumers choose consumption (Armington)
        for agent in self.agents:
            if isinstance(agent, Consumer):
                agent.choose_consumption()

        # 4) aggregate demand by firm
        self.demand = {firm_id: 0.0 for firm_id in self.prices}
        for agent in self.agents:
            if isinstance(agent, Consumer):
                indiv = agent.consume_queue[0]
                for firm_id, q in indiv.items():
                    self.demand[firm_id] += float(q)

        # 5) firms produce to match demand
        self.supply = {}
        for agent in self.agents:
            if isinstance(agent, Firm):
                produced = agent.produce(self.demand)
                self.supply[agent.unique_id] = float(produced)

        self.total_production = float(sum(self.supply.values()))

        # 6) consumers consume (and we compute tariff revenue on imports)
        total_value = 0.0
        import_value = 0.0
        total_qty = 0.0
        import_qty = 0.0
        tau_rev = 0.0

        for agent in self.agents:
            if isinstance(agent, Consumer):
                out = agent.consume()
                # compute shares using what was actually bought (out is composite info)
                Cd = float(out["Cd"])
                Cm = float(out["Cm"])
                total_qty += Cd + Cm
                import_qty += Cm

        # Value shares require prices; compute from aggregate demand as approximation:
        for firm_id, q in self.demand.items():
            firm = self.firms[firm_id]
            p = self.prices[firm_id]
            if firm.origin == "import":
                p_eff = p * (1.0 + self.tau)
                import_value += p_eff * q
                tau_rev += (p * self.tau) * q
                total_value += p_eff * q
            else:
                total_value += p * q

        self.import_share_qty = (import_qty / total_qty) if total_qty > 0 else 0.0
        self.import_share_value = (import_value / total_value) if total_value > 0 else 0.0
        self.tau_revenue = tau_rev

        # 7) record other aggregates
        self.avg_price = float(sum(self.prices.values()) / len(self.prices)) if self.prices else 0.0
        self.avg_utility = (
            float(sum(agent.utility for agent in self.agents if isinstance(agent, Consumer)) / self.num_consumers)
            if self.num_consumers > 0 else 0.0
        )

        # collect (before resets)
        self.datacollector.collect(self)

        # 8) firms update prices
        for agent in self.agents:
            if isinstance(agent, Firm):
                agent.update_prices()

        # 9) reset per-tick containers
        self.prices = {}
        self.demand = {}
        self.supply = {}
        self.total_production = 0.0
        self.avg_price = 0.0
        self.avg_utility = 0.0
        self.import_share_value = 0.0
        self.import_share_qty = 0.0
        self.tau_revenue = 0.0

        for agent in self.agents:
            agent.reset()
