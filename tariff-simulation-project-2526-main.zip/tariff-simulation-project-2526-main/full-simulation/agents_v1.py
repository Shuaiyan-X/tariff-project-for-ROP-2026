from mesa import Agent
import numpy as np

# Numerical safeguards
P_MIN = 1e-8
Q_MIN = 1e-12
S_MIN = 1e-12


class Household(Agent):
    """Household implementing the overview_v1.md logic."""

    def __init__(self, model, s=0.0, gamma=0.5, L=1, lambda_p=1.0, eta=0.9,
                 delta_x=0.6, delta_y=0.5, sigma_x=1.0, sigma_y=1.0, **kwargs):
        super().__init__(model)

        gamma = kwargs.get('theta', gamma)
        L = int(kwargs.get('N', kwargs.get('N_lookahead', L)))
        lambda_p = kwargs.get('lambda_p', kwargs.get('lambda_I', lambda_p))
        delta_x = kwargs.get('dx', kwargs.get('delta_x', delta_x))
        delta_y = kwargs.get('dy', kwargs.get('delta_y', delta_y))
        sigma_x = kwargs.get('sigma_x', sigma_x)
        sigma_y = kwargs.get('sigma_y', sigma_y)
        s = float(kwargs.get('s', s))

        self.s_share = float(s)
        self.gamma = float(gamma)
        self.L = int(L)
        self.lambda_p = float(lambda_p)
        self.eta = float(kwargs.get('eta', eta))
        self.delta_x = float(delta_x)
        self.delta_y = float(delta_y)
        self.sigma_x = float(sigma_x)
        self.sigma_y = float(sigma_y)

        self.p_hat = None
        self.inflation_hat = 0.0
        self.g_hat = 0.0
        self.price_history = []

        self.money = 0.0
        self.xd = self.xm = 0.0
        self.yd = self.ym = 0.0

    def get_price_level(self):
        p_xd = self.model.firm.p_gross.get('xd', P_MIN)
        p_xm = self.model.firm.p_gross.get('xm', P_MIN)
        p_yd = self.model.firm.p_gross.get('yd', P_MIN)
        p_ym = self.model.firm.p_gross.get('ym', P_MIN)

        def armington_price(p_d, p_m, delta, sigma):
            p_d = max(float(p_d), P_MIN)
            p_m = max(float(p_m), P_MIN)
            if sigma == 1.0:
                return np.exp(delta * np.log(p_d) + (1 - delta) * np.log(p_m))
            if sigma == 0.0:
                return delta * p_d + (1 - delta) * p_m
            return (delta * p_d ** (1 - sigma) + (1 - delta) * p_m ** (1 - sigma)) ** (1 / (1 - sigma))

        P_x = armington_price(p_xd, p_xm, self.delta_x, self.sigma_x)
        P_y = armington_price(p_yd, p_ym, self.delta_y, self.sigma_y)
        return float(max((P_x ** self.gamma) * (P_y ** (1 - self.gamma)), P_MIN))

    def update_expectations(self):
        P_t = self.get_price_level()
        self.price_history.append(P_t)
        if len(self.price_history) > 3:
            self.price_history.pop(0)

        if len(self.price_history) >= 3:
            P_tm2 = self.price_history[-3]
            self.pi_t = (P_t - P_tm2) / max(P_tm2, P_MIN)
        else:
            self.pi_t = 0.0

        g_history = getattr(self.model, 'gdp_history', [])
        if len(g_history) >= 3:
            Y_tm2 = g_history[-3]
            self.g_t = (g_history[-1] - Y_tm2) / max(Y_tm2, P_MIN)
        else:
            self.g_t = 0.0

        if self.p_hat is None:
            self.p_hat = float(P_t)
            self.inflation_hat = 0.0
            self.g_hat = 0.0
        else:
            self.p_hat = self.lambda_p * float(P_t) + (1 - self.lambda_p) * self.p_hat
            self.inflation_hat = self.lambda_p * self.pi_t + (1 - self.lambda_p) * self.inflation_hat
            self.g_hat = self.lambda_p * self.g_t + (1 - self.lambda_p) * self.g_hat

    def compute_income(self):
        Y_prev = getattr(self.model, 'last_GDP', 0.0)
        return float(self.s_share * float(Y_prev))

    def allocate_armington(self, C):
        p = self.model.firm.p_gross

        def ces_shares(p_d, p_m, delta, sigma):
            p_d = max(float(p_d), P_MIN)
            p_m = max(float(p_m), P_MIN)
            if sigma == 1.0:
                return float(delta), float(1 - delta)
            den = delta * p_d ** (1 - sigma) + (1 - delta) * p_m ** (1 - sigma)
            if den == 0 or not np.isfinite(den):
                return float(delta), float(1 - delta)
            s_d = delta * p_d ** (1 - sigma) / den
            s_m = (1 - delta) * p_m ** (1 - sigma) / den
            return float(s_d), float(s_m)

        s_xd, s_xm = ces_shares(p['xd'], p['xm'], self.delta_x, self.sigma_x)
        s_yd, s_ym = ces_shares(p['yd'], p['ym'], self.delta_y, self.sigma_y)

        E_x = self.gamma * C
        E_y = (1 - self.gamma) * C

        xd = (s_xd * E_x) / max(p.get('xd', P_MIN), P_MIN)
        xm = (s_xm * E_x) / max(p.get('xm', P_MIN), P_MIN)
        yd = (s_yd * E_y) / max(p.get('yd', P_MIN), P_MIN)
        ym = (s_ym * E_y) / max(p.get('ym', P_MIN), P_MIN)
        return float(xd), float(xm), float(yd), float(ym)

    def choose_consumption(self, transfer=0.0):
        self.update_expectations()
        income_nom = self.compute_income()
        M_t = float(self.money + income_nom + transfer)
        P_t = self.get_price_level()

        if P_t <= 0:
            real_now = 0.0
        else:
            real_now = income_nom / P_t

        hat_r = (1 + self.g_hat) / max(1 + self.inflation_hat, P_MIN) - 1
        future_sum = 0.0
        for i in range(1, self.L + 1):
            future_sum += real_now * ((1 + hat_r) ** i)
        bar_y = (real_now + future_sum) / (self.L + 1)

        C = min(P_t * self.eta * bar_y, M_t)
        xd, xm, yd, ym = self.allocate_armington(C)

        spending = xd * self.model.firm.p_gross['xd'] + xm * self.model.firm.p_gross['xm']
        spending += yd * self.model.firm.p_gross['yd'] + ym * self.model.firm.p_gross['ym']
        saving = max(0.0, M_t - spending)

        self.money = float(saving)
        self.xd, self.xm, self.yd, self.ym = xd, xm, yd, ym
        return xd, xm, yd, ym

    def inst_utility(self, xd, xm, yd, ym):
        def aggregate_q(delta, qd, qm, sigma):
            qd = max(float(qd), Q_MIN)
            qm = max(float(qm), Q_MIN)
            if sigma == 1:
                return float(np.exp(delta * np.log(qd) + (1 - delta) * np.log(qm)))
            if sigma == 0:
                return float(delta * qd + (1 - delta) * qm)
            weight = (sigma - 1) / sigma
            return float((delta * qd ** weight + (1 - delta) * qm ** weight) ** (1 / weight))

        x = aggregate_q(self.delta_x, xd, xm, self.sigma_x)
        y = aggregate_q(self.delta_y, yd, ym, self.sigma_y)
        return float((x ** self.gamma) * (y ** (1 - self.gamma)))


class Firm(Agent):
    GOODS = ['xd', 'xm', 'yd', 'ym']

    def __init__(self, model,
                 np_price=0.01,
                 eta_q=0.1,
                 eta_p=0.05,
                 alpha_m=0.01,
                 alpha_I=0.01,
                 c_d=1.0,
                 c_m=1.0,
                 a_mc=5.0,
                 b_mc=-1.5,
                 c_mc=1.0,
                 fixed_cost=0.0,
                 **kwargs):
        super().__init__(model)

        self.np_price = float(np_price)
        self.eta_q = float(eta_q)
        self.eta_p = float(eta_p)
        self.alpha_m = float(alpha_m)
        self.alpha_I = float(alpha_I)
        self.fixed_cost = float(fixed_cost)
        self.c = {'xd': float(c_d), 'xm': float(c_m), 'yd': float(c_d), 'ym': float(c_m)}
        self.a_mc = float(a_mc)
        self.b_mc = float(b_mc)
        self.c_mc = float(c_mc)

        self.p = {g: 1.0 for g in self.GOODS}
        self.p_gross = {g: 1.0 for g in self.GOODS}
        self.q = {g: 1.0 for g in self.GOODS}
        self.demand = {g: 0.0 for g in self.GOODS}
        self.sales = {g: 0.0 for g in self.GOODS}

        self.last_demand = {g: 0.0 for g in self.GOODS}
        self.last_sales = {g: 0.0 for g in self.GOODS}
        self._demand_buffer = []

    def register_demand(self, household, xd, xm, yd, ym):
        self._demand_buffer.append({'xd': xd, 'xm': xm, 'yd': yd, 'ym': ym})

    def clear_demand(self):
        self.demand = {g: 0.0 for g in self.GOODS}
        for bundle in self._demand_buffer:
            for g in self.GOODS:
                self.demand[g] += float(bundle.get(g, 0.0))
        self._demand_buffer = []

    def settle_sales(self):
        for g in self.GOODS:
            self.sales[g] = float(min(self.q[g], self.demand[g]))

    def MC(self, q, good):
        q = max(float(q), 0.0)
        a, b, c = self.a_mc, self.b_mc, self.c_mc
        val = c * (np.exp(-((1.0 / a) * q + b)) + ((1.0 / a) * q + b) ** 4)
        gov = getattr(self.model, 'gov', None)
        if good in ('xm', 'ym') and gov is not None and gov.is_active(self.model.time):
            return float((1 + gov.tau) * val)
        return float(val)

    def TC(self, q, good):
        q_val = max(float(q), 0.0)
        if q_val <= 0:
            return 0.0
        xs = np.linspace(0.0, q_val, num=100)
        ys = np.array([self.MC(x, good) for x in xs], dtype=float)
        widths = xs[1:] - xs[:-1]
        trapezoids = 0.5 * (ys[:-1] + ys[1:]) * widths
        return float(np.sum(trapezoids))

    def profit_per_good(self, g, q):
        sold = float(min(q, self.last_demand.get(g, 0.0)))
        return float(self.p[g] * sold - self.TC(q, g))

    def update_gross_prices_from_tariff(self):
        tau = getattr(self.model, 'gov', None).tau if getattr(self.model, 'gov', None) is not None else 0.0
        self.p_gross['xd'] = self.p['xd']
        self.p_gross['yd'] = self.p['yd']
        self.p_gross['xm'] = (1 + tau) * self.p['xm']
        self.p_gross['ym'] = (1 + tau) * self.p['ym']

    def update_decisions(self, period):
        if period % 2 == 1:
            for g in self.GOODS:
                qg = float(self.q.get(g, 0.0))
                pi_prime = float(self.p[g] - self.MC(qg, g))
                profit = self.profit_per_good(g, qg)
                direction = np.sign(profit) if profit != 0 else 1.0
                self.q[g] = float(max(0.0, qg - self.eta_q * pi_prime * direction))
        else:
            for g in self.GOODS:
                qg = float(self.q.get(g, 0.0))
                dg = float(self.last_demand.get(g, 0.0))
                if dg <= 0.0:
                    continue
                I_g = dg / max(qg, P_MIN) - 1.0
                factor = 1.0 + self.eta_p * np.tanh(I_g)
                self.p[g] = float(max(P_MIN, self.p[g] * factor))
        self.update_gross_prices_from_tariff()

    def finalize_period(self):
        self.last_demand = self.demand.copy()
        self.last_sales = self.sales.copy()


class Government(Agent):
    def __init__(self, model, tau=0.25, start=None, end=None, efficiency=1.0, **kwargs):
        super().__init__(model)
        self.tau = float(tau)
        self.start = start
        self.end = end
        self.efficiency = float(efficiency)
        self.revenue_buffer = 0.0
        self.transfers = {}

    def is_active(self, period=None):
        if period is None:
            period = getattr(self.model, 'time', 1)
        if self.start is None:
            return False
        if period < self.start:
            return False
        if self.end is not None and period > self.end:
            return False
        return True

    def apply_tariff(self, firm, period):
        firm.update_gross_prices_from_tariff()

    def collect_tariff(self, firm, period):
        if not self.is_active(period):
            self.revenue_buffer = 0.0
            return
        rev_xm = float(firm.p.get('xm', 0.0)) * float(firm.sales.get('xm', 0.0))
        rev_ym = float(firm.p.get('ym', 0.0)) * float(firm.sales.get('ym', 0.0))
        self.revenue_buffer = float(self.tau) * (rev_xm + rev_ym)

    def distribute_transfers(self, households):
        if not households:
            self.transfers = {}
            return
        amount = float(self.revenue_buffer * self.efficiency) / len(households)
        self.transfers = {h.unique_id: amount for h in households}
        self.revenue_buffer = 0.0

    def transfer_for(self, household):
        return float(self.transfers.get(household.unique_id, 0.0))
