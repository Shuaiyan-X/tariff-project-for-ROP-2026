# Overview

This is the final version of our model that we (the ROP 2025-26 team) settled on, after some iterations. In this model, households and firms make economic choices under realistic market frictions and incomplete information, and the government levies a tariff.

## Model

There are three agent types: Household, Firm, and Government. There are a large finite number of Households, each with a slightly different income share and consumption preference. There is a single Firm agent to represent competitive firms - a choice made for tractability and similarity to other macroeconomic models.

Time passes in a set of discrete periods (integer values starting from 1). In each time period, Households earn income based on their share of last period's output, and the Firm chooses prices and production of a domestic and international version of a "target good" and "composite good" (four goods in total), labeled $x_d, x_m, y_d, y_m$. Households then make consumption choices on these goods. If applicable, the Government collects taxes and distributes them back into the economy (to reflect the value of government services and transfers). At the end of each period, Households and the Firm adjust their expectations and information in preparation for the next period.

## Agents

### Households

Every household has an innate share in the economy given by $s\in (0, 1)$. The household earns income every period as given by $y_t=sY_{t-1}$, where $Y_{t-1}$ is the total GDP of the economy in the previous period. The household's choice is given in two parts. 

The first is that they decide how much of their money to spend in this period (and how much of it to save). To do this, they have expectations of inflation and GDP growth. These are given by
$$\hat \pi_t=\begin{cases}
\lambda\pi_t+(1-\lambda) \hat\pi_{t-1} & \text{$\hat\pi_{t-1}$ is defined} \\
\pi_t & \text{otherwise}
\end{cases}$$
$$\hat g_t=\begin{cases}
\lambda g_t+(1-\lambda) \hat g_{t-1} & \text{$\hat g_{t-1}$ is defined} \\
g_t & \text{otherwise}
\end{cases}$$

Here, $\lambda\in[0,1]$ controls how quickly households respond to new economic information. (1 indicates immediate and complete updates to new information.) Given that price levels and production levels are adjusted every other period (more on this later), the household computes
$\pi_t=\frac{P_t-P_{t-2}}{P_{t-2}}, g_t=\frac{Y_t-Y_{t-2}}{Y_{t-2}}$. Here, $P_t$ is a price aggregation computed by the household:
$$P_t(x_d, x_m, y_d, y_m)=[\delta_x p_{x_d}^{1-\sigma_x}+(1-\delta_x)p_{x_m}^{1-\sigma_x}]^{\frac{\gamma}{1-\sigma_x}} $$
$$\cdot [\delta_y p_{y_d}^{1-\sigma_y}+(1-\delta_y)p_{y_m}^{1-\sigma_y}]^{\frac{1-\gamma}{1-\sigma_y}}$$

These parameters are elaborated on later.

They calculate their real income using $y_t=\frac{I_t}{p_t}$ where $I_t$ is their nominal income for the period. From here, they estimate $\hat r_t=\frac{1+\hat g_t}{1+\hat \pi_t}-1$ and can forecast $\hat y_{t+i}=y_t(1+\hat r_t)^i$. From here, they compute $$\bar y_t=\frac{1}{L+1}(y_t+\sum\limits_{i=1}^L \hat y_{t+i})$$
where $L$ is the household's lookahead period. From there, the household chooses nominal consumption allocation given by $$C=\min \{P_t\cdot \eta\cdot \bar y_t, M_t\}$$

where $M_t$ is the household's current money level (after earning an income) and $\eta\in (0, 1]$ is the household's marginal propensity to consume.


Second, they maximize the per-period utility function
$$u_t(x_d, x_m, y_d, y_m)=A(x_d, x_m)^\gamma A(y_d, y_m)^{1-\gamma}$$

subject to $\sum\limits_{g\in G} p_g g\leq C$ where $G=\{x_d, x_m, y_d, y_m\}$ and $C$ is given from before.

Here, $\gamma\in (0, 1)$ represents the income split between domestic and international spending, while $A(\cdot)$ is the Armington goods aggregator function given by 
$$A(g_d, g_m)=[\delta_g g_d^{\frac{\sigma_g-1}{\sigma_g}}+(1-\delta_g)g_m^{\frac{\sigma_g-1}{\sigma_g}}]^{\frac{\sigma_g}{\sigma_g-1}}$$

Here, $\delta_g\in (0, 1)$ represents the bias for domestic goods - higher values indicate higher preference for domestic goods. $\sigma_g\geq0$ represents the elasticity of substitution between $g_d$ and $g_m$. (Note, $g$ is an arbitrary good - we would plug in $x, y$ in this case.)

Solving this maximization problem gives the following formulas:

* $x_d = \frac{\delta_x p_{x_d}^{-\sigma_x}}{\delta_x p_{x_d}^{1-\sigma_x}+(1-\delta_x)p_{x_m}^{1-\sigma_x}}\cdot (\gamma C)$

* $x_m = \frac{(1-\delta_x) p_{x_d}^{-\sigma_x}}{\delta_x p_{x_d}^{1-\sigma_x}+(1-\delta_x)p_{x_m}^{1-\sigma_x}}\cdot (\gamma C)$

* $y_d = \frac{\delta_y p_{y_d}^{-\sigma_y}}{\delta_y p_{y_d}^{1-\sigma_y}+(1-\delta_y)p_{y_m}^{1-\sigma_y}}\cdot ((1-\gamma) C)$

* $y_d = \frac{(1-\delta_y) p_{y_d}^{-\sigma_y}}{\delta_y p_{y_d}^{1-\sigma_y}+(1-\delta_y)p_{y_m}^{1-\sigma_y}}\cdot ((1-\gamma) C)$

If for a certain good, total demand exceeds total production, all households only get a fraction of those goods they sought to purchase (and only spend the correponding amount). The rest is automatically saved.


### Firms
There is a single representative firm that stands in for a competitive, but not necessarily efficient, market.

For each good $g$, firms can choose how many goods of each type to produce. In doing so, the firm faces a marginal cost (in terms of units of production) given by
$$MC_g(q_g)=c[e^{-(\frac{1}{a}q_g+b)}+(\frac{1}{a}q_g+b)^4]$$

where $a>0, b\in \mathbb{R}, c>0$ are parameters to adjust the functional form. Here, we set our default parameters to $a=5, b=-1.5, c=1$. This gives us a convex function which looks rather like a lopsided upward-facing parabola with a minimum around $q_g=10$. We can then define
$$TC_g(q_g)=F_g+\int\limits_0^{q_g} MC_g(t)dt$$

Firms also set prices for each good $g$. Naturally, revenue is given by $R_g=p_g \hat q_g$, where $\hat q_g=\max(q_g, d_g)$ is the amount of good $g$ sold on the market (either bottlenecked by chosen production or market demand). For simplicity's sake, we assume that firms do not carry over inventories and that they are able to directly observe $d_g$ irrespective of supply-demand imbalances. Thus, net profit per good is given by $$\pi_g (q_g)=p_g \hat q_g-TC_g(q_g)$$
which has derivative $\pi'_g(q_g)=p_g-MC_g(q_g)$.

To adjust towards net zero inventories and net zero profits, the Firm alternates between adjusting production quantities and production prices. On odd-numbered periods, for each good $g$, the Firm chooses a new level of production $$q_g'=q_g-\eta_q \pi_g'(q_g) \cdot \text{sign}[\pi_g(q_g)]$$ where $\eta_q$ is the learning rate for quantities (by default it's 0.1).

On even-numbered periods, the firm notices $I_g=q_g-d_g$ where $d_g$ is the amount of goods demanded for that period. New prices are determined by $$p_g'=p_g\times (1+\eta_p \tanh(I_g))$$ where $\eta_p$ is the learning rate for prices (by default it's 0.05).

## Government

The government has $\tau_x, \tau_y$ to refer to the tariff rate on the target good ($x$) and composite good ($y$). (By default, set $\tau_x=\tau_y=0.25$.) The government also has $START, END \in \mathbb{N}$ to refer to when the tariff starts and ends. Finally, the Government has an efficiency parameter $E\in [0, 1]$ that determines what percentage of tax revenue is returned as transfers (the rest is used for government services and the like). If $END$ is not defined but $START$ is, the tariff lasts indefinitely once enacted.

While a tariff on good $g$ is active, the marginal cost for the international version of good $g$ is uniformly multiplied by $1+\tau_g$. For example, with $\tau_x=0.25$, we get $MC_x(q_x) \to MC'_x(q_x)=1.25 MC_x (q_x)$.