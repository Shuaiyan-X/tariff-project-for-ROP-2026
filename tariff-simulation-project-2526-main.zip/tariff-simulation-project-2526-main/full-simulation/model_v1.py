from mesa import Model
from mesa.datacollection import DataCollector
from agents_v1 import Household, Firm, Government

class TariffModel(Model):
    """Tariff model orchestrating price and production updates directly."""

    def __init__(self,
                 N_households,
                 household_param_dist,
                 firm_params,
                 gov_params,
                 seed=None):
        super().__init__(seed=seed)

        self.time = 1
        self.firm = Firm(self, **firm_params)
        self.gov = Government(self, **gov_params)

        self.last_GDP = float(max(1.0, sum(self.firm.q.values())))
        self.gdp_history = [self.last_GDP]

        self.households = []
        for i in range(N_households):
            params = household_param_dist(i)
            h = Household(self, **params)
            self.households.append(h)

        class _Sched:
            pass

        self.schedule = _Sched()
        self.schedule.agents = self.households + [self.firm, self.gov]
        self.schedule.time = self.time

        self.datacollector = DataCollector(
            model_reporters={
                'avg_price_xd': lambda m: m.firm.p['xd'],
                'avg_price_xm': lambda m: m.firm.p['xm'],
                'avg_price_yd': lambda m: m.firm.p['yd'],
                'avg_price_ym': lambda m: m.firm.p['ym'],
                'total_output': lambda m: sum(m.firm.q.values()),
                'total_demand': lambda m: sum(m.firm.demand.values()),
                'total_inventory': lambda m: sum(float(m.firm.q[g] - m.firm.sales[g]) for g in m.firm.GOODS),
                'profit': lambda m: sum(m.firm.profit_per_good(g, m.firm.q[g]) for g in m.firm.GOODS),
                'tau_param': lambda m: getattr(m.gov, 'tau', None),
                'tariff_active': lambda m: m.gov.is_active(m.time),
                'tau_effective': lambda m: (getattr(m.gov, 'tau', 0.0) if m.gov.is_active(m.time) else 0.0),
                'gov_revenue_buffer': lambda m: getattr(m.gov, 'revenue_buffer', None),
                'total_sales': lambda m: sum(m.firm.sales.values()),
                'avg_transfer': lambda m: (sum(m.gov.transfers.values()) / len(m.gov.transfers)) if getattr(m.gov, 'transfers', None) else 0.0,
                'price_level': lambda m: m.households[0].get_price_level() if m.households else None,
            },
            agent_reporters={
                'agent_type': lambda a: type(a).__name__,
                'money': lambda a: getattr(a, 'money', None),
                'xd': lambda a: getattr(a, 'xd', None),
                'xm': lambda a: getattr(a, 'xm', None),
                'yd': lambda a: getattr(a, 'yd', None),
                'ym': lambda a: getattr(a, 'ym', None),
                'utility': lambda a: a.inst_utility(getattr(a, 'xd', 0.0), getattr(a, 'xm', 0.0), getattr(a, 'yd', 0.0), getattr(a, 'ym', 0.0)) if hasattr(a, 'inst_utility') else None,
                'profit': lambda a: a.compute_profit() if hasattr(a, 'compute_profit') else None,
            }
        )

    def step(self):
        self.gov.distribute_transfers(self.households)
        self.firm.update_decisions(self.time)
        self.gov.apply_tariff(self.firm, self.time)

        for household in self.households:
            transfer = self.gov.transfer_for(household)
            xd, xm, yd, ym = household.choose_consumption(transfer)
            self.firm.register_demand(household, xd, xm, yd, ym)

        self.firm.clear_demand()
        self.firm.settle_sales()
        self.firm.finalize_period()

        self.gov.collect_tariff(self.firm, self.time)

        self.last_GDP = float(sum(self.firm.sales.values()))
        self.gdp_history.append(self.last_GDP)
        if len(self.gdp_history) > 5:
            self.gdp_history.pop(0)

        if hasattr(self, 'schedule'):
            self.schedule.time = self.time

        self.datacollector.collect(self)
        self.time += 1
